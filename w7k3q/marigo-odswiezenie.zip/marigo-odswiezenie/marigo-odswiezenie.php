<?php
/**
 * Plugin Name: Marigo - odswiezenie 2026
 * Description: Nowy wyglad marigo.pl (strona glowna, strony jachtow, oprawa podstron i wpisow, naglowek, stopka, menu na telefonie), shortcody cen z /cennik/. Wylaczenie wtyczki przywraca dawny wyglad (tresc stron cofa sie przez Wersje).
 * Version: 10.0
 * Author: Lukasz Stasiak
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
define( 'MARIGO_PLIK', __FILE__ );
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'marigo-odswiezenie', plugins_url( 'style.css', __FILE__ ), array( 'generate-style' ), MARIGO_WERSJA );
}, 20 );

/* =====================================================================
 * MARIGO - odswiezenie 2026 (dopisac NA KONCU istniejacego functions.php
 * motywu potomnego generatepress-child; nie kasowac tego, co tam jest).
 * Jesli dopisujesz do pliku, ktory juz zaczyna sie od "<?php",
 * NIE kopiuj pierwszej linijki "<?php" z tego pliku.
 *
 * Co robi:
 *  1. klasy body dla nowej strony glownej i stron jachtow (sterowanie CSS),
 *  2. wszystkie strony, wpisy i blog bez bocznego paska (jedna szerokosc tresci),
 *  3. telefon w naglowku,
 *  4. lzejsze ladowanie: bez Google Fonts, bez zbednych skryptow na stronach,
 *  5. shortcody [marigo_cennik jacht="..."] i [marigo_cena jacht="..."]
 *     czytajace ceny z TABEL na stronie /cennik/ (jedno miejsce edycji cen),
 *  6. dolny pasek "Zadzwon / Wolne terminy / Zobacz jachty" na telefonie (po przewinieciu za 1. ekran),
 *  7. nowe zdjecia wgrywane do biblioteki dostaja miniatury WebP,
 *  8. nowa stopka (kontakt, port, linki, social media, linki prawne),
 *  9. czcionka tresci Source Sans 3 z plikow motywu (fonts/), bez Google Fonts,
 * 10. karty jachtow: jedno zrodlo (strona glowna), shortcode [marigo_flota],
 * 11. porzadki w starych tresciach: rabaty jako plakietki, "Czytaj wiecej" pod blokiem "Wiecej",
 *     karty jachtow na stronach ofert, listy z "•", pogrubione akapity, lekkie filmy YouTube.
 * 18. v9: uklad z pierwszej koncepcji (zakladki, ikonki, karuzela, poradniki, porty, rabaty i doplaty z /cennik/),
 * Formularze Contact Form 7, reCAPTCHA, hCaptcha i widget Yacht CMS
 * NIE sa ruszane.
 * ===================================================================== */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'MARIGO_TEL', '691 612 066' );
define( 'MARIGO_TEL_HREF', 'tel:+48691612066' );

/* ---------- 1. klasy body ---------- */
function marigo_tresc_zawiera( $fragment ) {
	if ( ! is_singular() ) { return false; }
	$post = get_queried_object();
	return $post && isset( $post->post_content ) && false !== strpos( $post->post_content, $fragment );
}
add_filter( 'body_class', function ( $classes ) {
	if ( marigo_tresc_zawiera( 'mg-hero' ) ) { $classes[] = 'mg-glowna'; }
	if ( marigo_tresc_zawiera( 'mg-jhero' ) ) { $classes[] = 'mg-jacht-strona'; }
	// zwykla strona albo wpis: tekst w jednej, wygodnej do czytania kolumnie
	if ( is_singular() && ! is_front_page() && ! in_array( 'mg-glowna', $classes, true ) && ! in_array( 'mg-jacht-strona', $classes, true ) ) { $classes[] = 'mg-zwykla'; }
	return $classes;
} );

/* ---------- 2. bez bocznego paska na wszystkich stronach ---------- */
add_filter( 'generate_sidebar_layout', function () { return 'no-sidebar'; }, 30 );

/* ---------- 3. telefon w naglowku (obok lupki) ---------- */
add_action( 'generate_menu_bar_items', function () {
	echo '<span class="menu-bar-item mg-tel"><a href="' . esc_attr( MARIGO_TEL_HREF ) . '" aria-label="Zadzwoń: ' . esc_attr( MARIGO_TEL ) . '">'
		. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg>'
		. '<span class="mg-tel-nr">' . esc_html( MARIGO_TEL ) . '</span></a></span>';
}, 5 );

/* ---------- 4. lzejsze ladowanie ---------- */
add_action( 'wp_enqueue_scripts', function () {
	// Google Fonts (Nunito 18 odmian + Poppins) - zastapione czcionka systemowa w style.css
	wp_dequeue_style( 'generate-fonts' );
	// pusty plik style.css motywu nadrzednego (GP 3 ma cale style w main.min.css)
	wp_dequeue_style( 'parent-style' );

	// strona glowna nie ma galerii z powiekszaniem: bez skryptu lightboxa (a z nim bez jQuery, ktore blokowalo wyswietlanie)
	if ( is_front_page() ) {
		wp_dequeue_script( 'wp-featherlight' );
		wp_dequeue_style( 'wp-featherlight' );
	}
	if ( is_page() ) {
		$tresc = (string) get_post_field( 'post_content', get_queried_object_id() );
		// oceny gwiazdkowe sa tylko we wpisach bloga
		if ( false === strpos( $tresc, 'kk-star' ) && false === strpos( $tresc, 'kkstarratings' ) ) {
			wp_dequeue_style( 'kk-star-ratings' );
			wp_dequeue_script( 'kk-star-ratings' );
		}
		// ikony social (Ultimate Social Media Icons) - na stronach nie sa wyswietlane
		foreach ( array( 'SFSIjqueryModernizr', 'SFSIjqueryShuffle', 'SFSIjqueryrandom-shuffle', 'SFSICustomJs' ) as $h ) {
			wp_dequeue_script( $h );
		}
		wp_dequeue_style( 'SFSImainCss' );
		// WP Show Posts tylko tam, gdzie jest jego shortcode
		if ( ! has_shortcode( $tresc, 'wp_show_posts' ) ) {
			wp_dequeue_style( 'wp-show-posts' );
		}
	}
}, 100 );

/* ---------- 5. ceny z tabel strony /cennik/ ---------- */
function marigo_norm( $s ) {
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
	return preg_replace( '/[^a-z0-9.ąćęłńóśźż]/u', '', $s );
}

/* Zwraca tabele z /cennik/ jako tablice wierszy (pierwszy wiersz = naglowki). Wynik w cache do zmiany strony. */
function marigo_tabele_cennika() {
	$strona = get_page_by_path( 'cennik' );
	if ( ! $strona ) { return array(); }
	$klucz = 'mg_cennik_' . $strona->ID . '_' . md5( $strona->post_modified_gmt );
	$cache = get_transient( $klucz );
	if ( is_array( $cache ) ) { return $cache; }

	$tabele = array();
	if ( class_exists( 'DOMDocument' ) && false !== stripos( $strona->post_content, '<table' ) ) {
		$dom = new DOMDocument();
		libxml_use_internal_errors( true );
		$dom->loadHTML( '<?xml encoding="utf-8"?><div>' . $strona->post_content . '</div>' );
		libxml_clear_errors();
		foreach ( $dom->getElementsByTagName( 'table' ) as $t ) {
			$wiersze = array();
			foreach ( $t->getElementsByTagName( 'tr' ) as $tr ) {
				$kom = array();
				foreach ( $tr->childNodes as $c ) {
					if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'td', 'th' ), true ) ) {
						$kom[] = trim( preg_replace( '/\s+/u', ' ', str_replace( "\xc2\xa0", ' ', $c->textContent ) ) );
					}
				}
				if ( $kom ) { $wiersze[] = $kom; }
			}
			if ( count( $wiersze ) > 1 ) { $tabele[] = $wiersze; }
		}
	}
	set_transient( $klucz, $tabele, WEEK_IN_SECONDS );
	return $tabele;
}

/* Szuka kolumny jachtu: najpierw dokladna nazwa, potem naglowek zawiera nazwe, potem nazwa zaczyna sie od naglowka. */
function marigo_kolumna( $jacht ) {
	$n = marigo_norm( $jacht );
	if ( '' === $n ) { return null; }
	$tabele = marigo_tabele_cennika();
	foreach ( array( 'dokladnie', 'naglowek', 'nazwa' ) as $tryb ) {
		foreach ( $tabele as $t ) {
			foreach ( $t[0] as $i => $nagl ) {
				if ( 0 === $i ) { continue; }
				$h = marigo_norm( $nagl );
				if ( '' === $h ) { continue; }
				$ok = ( 'dokladnie' === $tryb && $h === $n )
					|| ( 'naglowek' === $tryb && false !== strpos( $h, $n ) )
					// "Tes 32 Dreamer" pasuje do kolumny "Tes 32", ale "Antila 33.2" NIE do "Antila 33"
					|| ( 'nazwa' === $tryb && 0 === strpos( $n, $h ) && preg_match( '/^\p{L}/u', substr( $n, strlen( $h ) ) ) );
				if ( $ok ) { return array( 'tabela' => $t, 'kol' => $i ); }
			}
		}
	}
	return null;
}

function marigo_kwota( $v ) {
	$liczba = preg_replace( '/[^0-9]/', '', $v );
	if ( '' === $liczba || ! preg_match( '/^\s*[0-9][0-9\s.]*\s*(zł|pln)?\s*$/iu', $v ) ) { return esc_html( $v ); }
	return esc_html( number_format( (int) $liczba, 0, ',', ' ' ) ) . ' zł';
}

/* 28.10: termin "15.04.-29.04." -> "15 kwi - 29 kwi" */
function marigo_termin( $t ) {
	$mies = array( 'sty', 'lut', 'mar', 'kwi', 'maja', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru' );
	$d = function ( $dz, $m ) use ( $mies ) {
		$m = (int) $m;
		return ( $m >= 1 && $m <= 12 ) ? (int) $dz . ' ' . $mies[ $m - 1 ] : $dz . '.' . $m;
	};
	$t = trim( $t );
	if ( preg_match( '/^(\d{1,2})\.(\d{1,2})\.?\s*-\s*(\d{1,2})\.(\d{1,2})\.?$/', $t, $m ) ) {
		return $d( $m[1], $m[2] ) . ' - ' . $d( $m[3], $m[4] );
	}
	if ( preg_match( '/^(po|od|do)\s+(\d{1,2})\.(\d{1,2})\.?$/u', $t, $m ) ) {
		return $m[1] . ' ' . $d( $m[2], $m[3] );
	}
	return $t;
}

function marigo_zl( $n ) {
	return number_format( (int) $n, 0, ',', ' ' ) . ' zł';
}

/* ---------- 5a. cennik jachtu (v5): polecane terminy, pasek sezonu, ceny pogrupowane wg ceny ----------
   Dane: kolumna jachtu z tabel /cennik/ (klientka edytuje tylko tabele). Wiersze z data "15.04.-29.04." = okresy,
   wiersze bez daty (Kaucja, Sprzatanie) = oplaty dodatkowe. */

/* rok sezonu: od pazdziernika pokazujemy kolejny sezon */
function marigo_rok_sezonu() {
	$r = (int) current_time( 'Y' );
	return ( (int) current_time( 'n' ) >= 10 ) ? $r + 1 : $r;
}

/* dzien roku (0 = 1 stycznia) dla dnia i miesiaca w danym roku */
function marigo_dzien( $d, $m, $rok ) {
	return (int) floor( ( gmmktime( 0, 0, 0, (int) $m, (int) $d, $rok ) - gmmktime( 0, 0, 0, 1, 1, $rok ) ) / 86400 );
}

/* Boze Cialo = Wielkanoc + 60 dni (algorytm Meeusa, bez rozszerzenia calendar) */
function marigo_boze_cialo( $rok ) {
	$a = $rok % 19; $b = intdiv( $rok, 100 ); $c = $rok % 100; $d = intdiv( $b, 4 ); $e = $b % 4;
	$f = intdiv( $b + 8, 25 ); $g = intdiv( $b - $f + 1, 3 ); $h = ( 19 * $a + $b - $d - $g + 15 ) % 30;
	$i = intdiv( $c, 4 ); $k = $c % 4; $l = ( 32 + 2 * $e + 2 * $i - $h - $k ) % 7; $m = intdiv( $a + 11 * $h + 22 * $l, 451 );
	$mies = intdiv( $h + $l - 7 * $m + 114, 31 ); $dz = ( ( $h + $l - 7 * $m + 114 ) % 31 ) + 1;
	return marigo_dzien( $dz, $mies, $rok ) + 60;
}

/* okresy jachtu: [ od, do (dzien roku), tekst terminu, cena ] oraz oplaty dodatkowe [ nazwa, tekst ] */
function marigo_cennik_okresy( $t, $i ) {
	$rok = marigo_rok_sezonu();
	$okresy = array();
	$dod = array();
	for ( $r = 1; $r < count( $t ); $r++ ) {
		$w = $t[ $r ];
		if ( ! isset( $w[ $i ] ) ) { continue; }
		$termin = trim( $w[0] );
		$cena = (int) preg_replace( '/[^0-9]/', '', $w[ $i ] );
		if ( ! preg_match( '/^\s*[0-9][0-9\s.]*\s*(zł|pln)?\s*$/iu', $w[ $i ] ) ) { $cena = 0; }
		if ( preg_match( '/^(\d{1,2})\.(\d{1,2})\.?\s*-\s*(\d{1,2})\.(\d{1,2})\.?$/', $termin, $m ) ) {
			$okresy[] = array( marigo_dzien( $m[1], $m[2], $rok ), marigo_dzien( $m[3], $m[4], $rok ), $termin, $cena );
		} elseif ( preg_match( '/^(po|od)\s+(\d{1,2})\.(\d{1,2})\.?$/u', $termin, $m ) ) {
			// "po 30.09" - do konca pazdziernika
			$okresy[] = array( marigo_dzien( $m[2], $m[3], $rok ), marigo_dzien( 31, 10, $rok ), $termin, $cena );
		} elseif ( '' !== trim( $w[ $i ] ) && ! preg_match( '/\d{1,2}\.\d{1,2}/', $termin ) ) {
			$dod[] = array( $termin, $w[ $i ] );
		}
	}
	return array( $okresy, $dod, $rok );
}

/* poziom ceny 1-5 (kolor skali) */
function marigo_poziom( $n, $lo, $hi ) {
	if ( $hi <= $lo ) { return 3; }
	return 1 + (int) min( 4, floor( 5 * ( $n - $lo ) / ( $hi - $lo + 0.0001 ) ) );
}

/* data dnia roku slownie, pelna nazwa miesiaca: "15 kwietnia" */
function marigo_data_slownie( $dzien, $rok ) {
	$mies = array( 'stycznia', 'lutego', 'marca', 'kwietnia', 'maja', 'czerwca', 'lipca', 'sierpnia', 'września', 'października', 'listopada', 'grudnia' );
	$ts = gmmktime( 0, 0, 0, 1, 1, $rok ) + $dzien * 86400;
	return (int) gmdate( 'j', $ts ) . ' ' . $mies[ (int) gmdate( 'n', $ts ) - 1 ];
}

/* v7: cennik jachtu jako prosta lista terminow (od najwczesniejszego): data slownie | cena za dobe i za tydzien,
   z kreska koloru sezonu i podpisem przy zmianie sezonu; pod lista kaucja, sprzatanie i linki. */
function marigo_cennik_tabela_html( $t, $i, $tydz = true, $uwagi = true ) {
	/* v9 (29.10): cennik jachtu jak w pierwszej koncepcji - tabela Termin | Doba | Tydzien, WSZYSTKIE terminy z tabeli /cennik/
	   (takze od 29.08 do konca sezonu), kreska koloru sezonu przy terminie; pod tabela kaucja, sprzatanie i linki. */
	list( $okresy, $dod, $rok ) = marigo_cennik_okresy( $t, $i );
	$ceny = array_filter( wp_list_pluck( $okresy, 3 ) );
	if ( ! $ceny ) {
		return '<p class="mg-mala">Cena na zapytanie - zadzwoń: <a href="' . esc_attr( MARIGO_TEL_HREF ) . '">' . esc_html( MARIGO_TEL ) . '</a>.</p>';
	}
	$lo = min( $ceny );
	$hi = max( $ceny );
	$nazwa = isset( $t[0][ $i ] ) ? trim( $t[0][ $i ] ) : '';
	$dm = function ( $dzien ) use ( $rok ) { $ts = gmmktime( 0, 0, 0, 1, 1, $rok ) + $dzien * 86400; return gmdate( 'd.m', $ts ); };
	$h = '<div class="mg-cj m9-cj">';
	$h .= '<p class="mg-cj-od">od <b>' . marigo_zl( $lo ) . '</b> za dobę' . ( $tydz ? ' · tydzień od <b>' . marigo_zl( 7 * $lo ) . '</b>' : '' ) . '</p>';
	$h .= '<div class="m9-ctab-w"><table class="m9-ctab"><thead><tr><th scope="col">Termin</th><th scope="col">Doba</th>' . ( $tydz ? '<th scope="col">Tydzień (7 dób)</th>' : '' ) . '</tr></thead><tbody>';
	foreach ( $okresy as $ok ) {
		$p = $hi > $lo ? ( $ok[3] - $lo ) / ( $hi - $lo ) : 0;
		$poz = $p < 0.34 ? 1 : ( $p < 0.67 ? 2 : 3 );
		$termin = preg_match( '/^(po|od)\s/u', $ok[2] ) ? 'po ' . $dm( $ok[0] ) : $dm( $ok[0] ) . ' - ' . $dm( $ok[1] );
		if ( ! $ok[3] ) {
			$h .= '<tr class="mg-s0"><td>' . esc_html( $termin ) . '</td><td colspan="' . ( $tydz ? 2 : 1 ) . '">cena na zapytanie</td></tr>';
			continue;
		}
		$h .= '<tr class="mg-s' . $poz . '"><td>' . esc_html( $termin ) . '</td><td><b>' . marigo_zl( $ok[3] ) . '</b></td>' . ( $tydz ? '<td>' . marigo_zl( 7 * $ok[3] ) . '</td>' : '' ) . '</tr>';
	}
	$h .= '</tbody></table></div>';
	if ( $dod ) {
		$cz = array();
		foreach ( $dod as $d ) { $cz[] = esc_html( $d[0] ) . ' ' . marigo_kwota( $d[1] ); }
		$h .= '<p class="mg-cj-dod">' . implode( ' · ', $cz ) . ' (płatne osobno)</p>';
	}
	$uwaga = trim( $t[0][0] );
	if ( '' !== $uwaga && preg_match( '/\d/', $uwaga ) ) {
		$uwaga = function_exists( 'mb_strtolower' ) ? mb_strtolower( $uwaga, 'UTF-8' ) : strtolower( $uwaga );
		$h .= '<p class="mg-cj-dod">W sezonie ' . esc_html( $uwaga ) . '.</p>';
	}
	$h .= '<p class="mg-cj-linki">';
	if ( $uwagi ) { $h .= '<a href="' . esc_url( home_url( '/cennik/' ) ) . '#rabaty">Rabaty i dopłaty</a>'; }
	if ( '' !== $nazwa ) { $h .= '<a href="' . esc_url( add_query_arg( 'jacht', rawurlencode( $nazwa ), home_url( '/cennik/' ) ) ) . '#szukaj">Policz cenę na swój termin</a>'; }
	$h .= '</p></div>';
	return $h;
}

add_shortcode( 'marigo_cennik', function ( $atts ) {
	$a = shortcode_atts( array( 'jacht' => '', 'tydzien' => 'tak' ), $atts );
	$link = '<a href="' . esc_url( home_url( '/cennik/' ) ) . '">cennik</a>';
	$k = marigo_kolumna( $a['jacht'] );
	if ( ! $k ) {
		return '<p class="mg-mala">Cena na zapytanie - zadzwoń: <a href="' . esc_attr( MARIGO_TEL_HREF ) . '">' . esc_html( MARIGO_TEL ) . '</a>.</p>';
	}
	return marigo_cennik_tabela_html( $k['tabela'], $k['kol'], 'tak' === $a['tydzien'] );
} );

add_shortcode( 'marigo_cena', function ( $atts ) {
	$a = shortcode_atts( array( 'jacht' => '' ), $atts );
	$k = marigo_kolumna( $a['jacht'] );
	$min = 0;
	if ( $k ) {
		for ( $r = 1; $r < count( $k['tabela'] ); $r++ ) {
			$w = $k['tabela'][ $r ];
			if ( isset( $w[ $k['kol'] ] ) && preg_match( '/\d{1,2}\.\d{1,2}/', $w[0] ) ) {
				$v = (int) preg_replace( '/[^0-9]/', '', $w[ $k['kol'] ] );
				if ( $v > 0 && ( 0 === $min || $v < $min ) ) { $min = $v; }
			}
		}
	}
	if ( ! $min ) { return '<span class="mg-cena-brak">cena na zapytanie</span>'; }
	return 'od <strong>' . esc_html( number_format( $min, 0, ',', ' ' ) ) . ' zł</strong> / doba';
} );

/* ---------- 6. dolny pasek na telefonie ---------- */
/* Pokazuje sie dopiero po przewinieciu za pierwszy ekran (na kazdej stronie), znika w menu.
   Stopka ma na telefonie dolny odstep, wiec pasek nigdy nie zaslania konca strony. */
add_action( 'wp_footer', function () {
	$jacht = marigo_tresc_zawiera( 'mg-jhero' ) && marigo_tresc_zawiera( 'id="kalendarz"' );
	if ( $jacht ) {
		$cel = '#kalendarz'; $napis = 'Wolne terminy';
	} elseif ( marigo_tresc_zawiera( 'mg-hero' ) ) {
		$cel = '#flota'; $napis = 'Zobacz jachty';
	} else {
		$cel = home_url( '/#flota' ); $napis = 'Zobacz jachty';
	}
	echo '<div class="mg-mob" id="mg-mob"><a class="mg-mob-tel" href="' . esc_attr( MARIGO_TEL_HREF ) . '">Zadzwoń</a><a class="mg-mob-cta" href="' . esc_url( $cel ) . '">' . esc_html( $napis ) . '</a></div>';
	echo "<script>(function(){var p=document.getElementById('mg-mob');if(!p)return;var t=0;function u(){t=0;p.classList.toggle('widac',window.scrollY>window.innerHeight*.85)}addEventListener('scroll',function(){if(!t){t=1;requestAnimationFrame(u)}},{passive:true});u()})();</script>";
} );
/* ---------- 7. nowe zdjecia: miniatury w WebP (oryginal zostaje) ---------- */
add_filter( 'image_editor_output_format', function ( $formaty ) {
	if ( function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) ) ) {
		$formaty['image/jpeg'] = 'image/webp';
	}
	return $formaty;
} );


/* ---------- 8. stopka ---------- */
/* Nowa stopka drukowana przez motyw. Stary Element GP "Site Footer" wylacz (Elementy -> szkic),
   a gdyby zostal wlaczony, style.css i tak go ukrywa (.site-footer > :not(.mg-stopka)). */
add_action( 'after_setup_theme', function () {
	remove_action( 'generate_footer', 'generate_construct_footer_widgets', 5 );
	remove_action( 'generate_footer', 'generate_construct_footer' );
}, 20 );

function marigo_ikona( $nazwa ) {
	$d = array(
		'tel'  => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
		'mail' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
		'pin'  => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
		'fb'   => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>',
		'yt'   => '<path d="M22.5 6.4a2.8 2.8 0 0 0-2-2C18.8 4 12 4 12 4s-6.8 0-8.5.4a2.8 2.8 0 0 0-2 2A29 29 0 0 0 1 12a29 29 0 0 0 .5 5.6 2.8 2.8 0 0 0 2 2c1.7.4 8.5.4 8.5.4s6.8 0 8.5-.4a2.8 2.8 0 0 0 2-2A29 29 0 0 0 23 12a29 29 0 0 0-.5-5.6z"/><path d="m9.8 15.3 5.7-3.3-5.7-3.3z"/>',
	);
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $d[ $nazwa ] . '</svg>';
}

add_action( 'generate_footer', function () {
	$u = function ( $sciezka ) { return esc_url( home_url( $sciezka ) ); };
	$linki = array(
		'/zaglowki/'                                      => 'Jachty żaglowe',
		'/czarter-jachtow-motorowych-mazury/'             => 'Jachty motorowe',
		'/czarter-jachtow-motorowych-mazury/bez-patentu/' => 'Czarter bez patentu',
		'/houseboat-mazury/'                              => 'Houseboat',
		'/cennik/'                                        => 'Cennik',
		'/home/czarter-jachtow-mazury-last-minute/'       => 'Last minute',
		'/blog/'                                          => 'Blog',
		'/o-nas/'                                         => 'O nas',
		'/kontakt/'                                       => 'Kontakt',
	);
	$porty = array( '/ruciane-nida/' => 'Ruciane-Nida', '/czarter-piekna-gora/' => 'Piękna Góra', '/gizycko/' => 'Giżycko' );
	echo '<footer class="mg-stopka" aria-label="Stopka"><div class="mg-st-in">';
	if ( ! is_front_page() && function_exists( 'rank_math_the_breadcrumbs' ) ) {
		echo '<div class="mg-st-okruszki">';
		rank_math_the_breadcrumbs();
		echo '</div>';
	}
	echo '<div class="mg-st-gora">';

	echo '<div class="mg-st-marka">'
		. '<a class="mg-st-nazwa" href="' . $u( '/' ) . '">Marigo Czarter</a>'
		. '<p>Czarter jachtów żaglowych i motorowych na Mazurach z portu Sztynort. Własna flota od 2002 roku, rezerwacja bezpośrednio u właścicieli.</p>'
		. '<div class="mg-st-social">'
		. '<a href="https://www.facebook.com/MarigoCzarterMazury" target="_blank" rel="noopener" aria-label="Marigo na Facebooku">' . marigo_ikona( 'fb' ) . '</a>'
		. '<a href="https://www.youtube.com/@marigoCzarter" target="_blank" rel="noopener" aria-label="Filmy Marigo na YouTube">' . marigo_ikona( 'yt' ) . '</a>'
		. '</div></div>';

	echo '<div class="mg-st-kontakt"><p class="mg-st-h">Kontakt i rezerwacje</p>'
		. '<a class="mg-st-poz" href="tel:+48691612066">' . marigo_ikona( 'tel' ) . '<span><b>691 612 066</b><small>Małgorzata Milewicz-Siennicka</small></span></a>'
		. '<a class="mg-st-poz" href="tel:+48693734645">' . marigo_ikona( 'tel' ) . '<span><b>693 734 645</b><small>Mariusz Siennicki</small></span></a>'
		. '<a class="mg-st-poz" href="mailto:biuro@marigo.pl">' . marigo_ikona( 'mail' ) . '<span><b>biuro@marigo.pl</b><small>odpowiadamy 7 dni w tygodniu</small></span></a>'
		. '<p class="mg-st-godz">Biuro: pon-niedz 8:00-20:00<br>Sezon: od połowy kwietnia do października</p></div>';

	echo '<div class="mg-st-port"><p class="mg-st-h">Port Sztynort</p>'
		. '<p>Sztynort Duży 11, 11-600 Węgorzewo<br>Keja nr 4: wydanie jachtów 16:00-20:00, zdanie do 10:00</p>'
		. '<a class="mg-st-mapa" href="https://www.google.com/maps?cid=15749309610134002816" target="_blank" rel="noopener">' . marigo_ikona( 'pin' ) . 'Pokaż na mapie</a></div>';

	echo '<nav class="mg-st-linki" aria-label="Na skróty"><p class="mg-st-h">Na skróty</p><ul>';
	foreach ( $linki as $sc => $t ) { echo '<li><a href="' . $u( $sc ) . '">' . esc_html( $t ) . '</a></li>'; }
	echo '</ul><p class="mg-st-porty">Czarter z innych portów: ';
	$i = 0;
	foreach ( $porty as $sc => $t ) { echo ( $i++ ? ', ' : '' ) . '<a href="' . $u( $sc ) . '">' . esc_html( $t ) . '</a>'; }
	echo '</p></nav>';

	echo '</div>'; // mg-st-gora
	echo '<div class="mg-st-dol"><span>© ' . esc_html( date( 'Y' ) ) . ' PHU Marigo Mariusz Siennicki</span>'
		. '<span class="mg-st-prawne"><a href="' . $u( '/regulamin-czarteru-wazne/' ) . '">Regulamin czarteru</a>'
		. '<a href="' . $u( '/regulamin-rezerwacji-online/' ) . '">Regulamin rezerwacji online</a>'
		. '<a href="' . $u( '/polityka-prywatnosci/' ) . '">Polityka prywatności</a></span></div>';
	echo '</div></footer>';
}, 1 );

/* ---------- 9. czcionka tresci (Source Sans 3, pliki w motywie potomnym: fonts/) ---------- */
add_action( 'wp_head', function () {
	$u = plugins_url( 'fonts/', MARIGO_PLIK );
	foreach ( array( 'source-sans-3-latin.woff2', 'source-sans-3-pl.woff2' ) as $f ) {
		echo '<link rel="preload" href="' . esc_url( $u . $f ) . '" as="font" type="font/woff2" crossorigin>' . "\n";
	}
}, 2 );

/* ---------- 10. karty jachtow: jedno zrodlo = karty na stronie glownej ---------- */
/* Karty jachtow (zdjecie, nazwa, parametry, cena z /cennik/) edytuje sie TYLKO na stronie glownej.
   Shortcode [marigo_flota typ="motorowe|zaglowe|bez-patentu|wszystkie"] pokazuje te same karty na innych stronach,
   a stare kafelki z GenerateBlocks (zdjecie + NAZWA + "od ... PLN /doba" + "Wiecej informacji") na stronach ofert
   sa automatycznie zamieniane na te same karty (punkt 11 c). */
function marigo_dom( $html ) {
	// samozamykajace sie znaczniki SVG - parser HTML (libxml) zagniezdzalby je w sobie
	$html = preg_replace( '#<(path|circle|rect|line|polyline|polygon|ellipse|use|stop)(\s[^<>]*?)?\s*/>#i', '<$1$2></$1>', $html );
	$dom = new DOMDocument();
	libxml_use_internal_errors( true );
	$dom->loadHTML( '<?xml encoding="utf-8"?><html><body><div id="mgx-root">' . $html . '</div></body></html>', LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	return $dom;
}
function marigo_dom_html( $dom ) {
	$root = $dom->getElementById( 'mgx-root' );
	$out = '';
	if ( $root ) { foreach ( $root->childNodes as $c ) { $out .= $dom->saveHTML( $c ); } }
	return $out;
}
function marigo_ma_klase( $el, $klasa ) {
	return $el instanceof DOMElement && preg_match( '/(^|\s)' . preg_quote( $klasa, '/' ) . '(\s|$)/', (string) $el->getAttribute( 'class' ) );
}
function marigo_dodaj_klase( $el, $klasa ) {
	if ( ! marigo_ma_klase( $el, $klasa ) ) { $el->setAttribute( 'class', trim( $el->getAttribute( 'class' ) . ' ' . $klasa ) ); }
}
function marigo_sciezka( $url ) {
	return trim( (string) wp_parse_url( (string) $url, PHP_URL_PATH ), '/' );
}

/* Karty ze strony glownej: lista [sciezka, typ, bez_patentu, html]. W cache do zmiany strony glownej lub cennika. */
function marigo_karty() {
	static $karty = null;
	if ( null !== $karty ) { return $karty; }
	$karty = array();
	$id = (int) get_option( 'page_on_front' );
	if ( ! $id || ! class_exists( 'DOMDocument' ) ) { return $karty; }
	$gl = get_post( $id );
	$cen = get_page_by_path( 'cennik' );
	$klucz = 'mg_karty_' . md5( $gl->post_modified_gmt . ( $cen ? $cen->post_modified_gmt : '' ) . MARIGO_WERSJA );
	$c = get_transient( $klucz );
	if ( is_array( $c ) ) { $karty = $c; return $karty; }
	$html = do_shortcode( do_blocks( $gl->post_content ) );
	if ( function_exists( 'wp_filter_content_tags' ) ) { $html = wp_filter_content_tags( $html ); }
	$dom = marigo_dom( $html );
	foreach ( $dom->getElementsByTagName( 'article' ) as $a ) {
		if ( ! marigo_ma_klase( $a, 'mg-jacht' ) ) { continue; }
		$link = null;
		foreach ( $a->getElementsByTagName( 'a' ) as $l ) { $link = $l; break; }
		if ( ! $link ) { continue; }
		foreach ( $a->getElementsByTagName( 'img' ) as $im ) {
			$im->setAttribute( 'loading', 'lazy' );
			$im->setAttribute( 'decoding', 'async' );
			$im->removeAttribute( 'fetchpriority' );
		}
		$tekst = function_exists( 'mb_strtolower' ) ? mb_strtolower( $a->textContent, 'UTF-8' ) : strtolower( $a->textContent );
		$karty[] = array(
			'sciezka' => marigo_sciezka( $link->getAttribute( 'href' ) ),
			'typ'     => false !== strpos( $tekst, 'żaglow' ) ? 'zaglowe' : 'motorowe',
			'bez'     => false !== strpos( $tekst, 'bez patentu' ),
			'html'    => $dom->saveHTML( $a ),
		);
	}
	set_transient( $klucz, $karty, WEEK_IN_SECONDS );
	return $karty;
}
define( 'MARIGO_WERSJA', '10.0' );

/* v8: "Zobacz podobne jachty" na stronach jachtow: 3 karty tego samego typu (karty ze strony glownej), bez biezacego jachtu.
   [marigo_podobne typ="zaglowe|motorowe" bez="sciezka"] - bez: pomin jachty, ktorych adres zaczyna sie od tej sciezki. */
/* v8: opis jachtu nad galeria (grupa mg-jintro) na telefonie skrocony do 4 linii z przyciskiem "Czytaj dalej" (tekst caly w kodzie strony) */
add_action( 'wp_footer', function () {
	if ( ! marigo_tresc_zawiera( 'mg-jintro' ) ) { return; }
	echo "<script>(function(){var d=document.querySelector('.mg-jintro');if(!d||!d.textContent.trim()||window.innerWidth>781)return;d.classList.add('mg-jintro-js');if(d.scrollHeight<=d.clientHeight+8){d.classList.remove('mg-jintro-js');return;}var b=document.createElement('button');b.type='button';b.className='mg-jintro-btn';b.textContent='Czytaj dalej';b.setAttribute('aria-expanded','false');d.parentNode.insertBefore(b,d.nextSibling);b.addEventListener('click',function(){var o=d.classList.toggle('mg-jintro-otw');b.textContent=o?'Zwiń':'Czytaj dalej';b.setAttribute('aria-expanded',o?'true':'false')})})();</script>";
}, 60 );

add_shortcode( 'marigo_podobne', function ( $atts ) {
	$a = shortcode_atts( array( 'typ' => '', 'ile' => 3, 'bez' => '' ), $atts );
	$teraz = marigo_sciezka( get_permalink() );
	$bez = trim( (string) $a['bez'], '/' );
	$typ = sanitize_key( $a['typ'] );
	$karty = array_values( marigo_karty() );
	$poz = 0;
	foreach ( $karty as $i => $k ) { if ( $k['sciezka'] === $teraz ) { $poz = $i; if ( '' === $typ ) { $typ = $k['typ']; } } }
	$lista = array();
	foreach ( $karty as $i => $k ) {
		if ( $k['sciezka'] === $teraz || ( '' !== $bez && 0 === strpos( $k['sciezka'], $bez ) ) ) { continue; }
		if ( '' !== $typ && $typ !== $k['typ'] ) { continue; }
		$lista[] = array( abs( $i - $poz ), $i, $k['html'] );
	}
	// najpierw jachty stojace na stronie glownej najblizej biezacego
	usort( $lista, function ( $x, $y ) { return $x[0] === $y[0] ? $x[1] - $y[1] : $x[0] - $y[0]; } );
	$lista = array_slice( $lista, 0, max( 1, (int) $a['ile'] ) );
	if ( ! $lista ) { return ''; }
	$html = '';
	foreach ( $lista as $k ) { $html .= $k[2]; }
	return '<div class="mg-flota mg-flota-podobne">' . $html . '</div>';
} );

function marigo_flota_html( $typ = 'wszystkie', $sciezki = array() ) {
	$wynik = '';
	if ( $sciezki ) {
		$wg = array();
		foreach ( marigo_karty() as $k ) { $wg[ $k['sciezka'] ] = $k['html']; }
		foreach ( $sciezki as $s ) { if ( isset( $wg[ $s ] ) ) { $wynik .= $wg[ $s ]; } }
	} else {
		foreach ( marigo_karty() as $k ) {
			if ( 'wszystkie' === $typ || $typ === $k['typ'] || ( 'bez-patentu' === $typ && $k['bez'] ) ) { $wynik .= $k['html']; }
		}
	}
	return $wynik ? '<div class="mg-flota">' . $wynik . '</div>' : '';
}
add_shortcode( 'marigo_flota', function ( $atts ) {
	$a = shortcode_atts( array( 'typ' => 'wszystkie', 'tytul' => '', 'jachty' => '' ), $atts );
	$sc = array_values( array_filter( array_map( function ( $x ) { return trim( $x, ' /' ); }, explode( ',', (string) $a['jachty'] ) ) ) );
	$html = marigo_flota_html( sanitize_key( $a['typ'] ), $sc );
	return ( $html && '' !== $a['tytul'] ? '<h2 class="mg-flota-tyt mg-flota-naglowek">' . esc_html( $a['tytul'] ) . '</h2>' : '' ) . $html;
} );

/* ---------- 11. porzadki w starych tresciach (tylko wyglad, tekst i adresy bez zmian) ---------- */
/* a) Cale akapity zapisane jako naglowek (H2-H6, ponad 140 znakow) -> klasa "mgx-dlugi" = wstep (znacznik zostaje, SEO bez zmian).
   b) Mala "etykieta" nad naglowkiem (akapit GenerateBlocks tuz przed H2/H3): krotka jest ukrywana, dluzsza = naglowek ("mgx-nad").
   c) Stare kafelki jachtow -> te same karty co na stronie glownej (ceny z /cennik/).
   d) Obrazki rabatow ("-10% OFF", "-5%") wklejone w akapit -> plakietka wielkosci tekstu, akapit w ramce promocji.
   e) Akapity sklejone podwojnym <br> -> osobne akapity; linie zaczynajace sie od "•" -> zwykla lista.
   f) Calkowicie pogrubiony krotki akapit = podtytul, dlugi = zwykly tekst (bez "krzyczenia").
   g) Filmy YouTube: lekki podglad (zdjecie + przycisk), odtwarzacz laduje sie po kliknieciu.
   h) "Czytaj wiecej": na stronach (nie we wpisach) wszystko pod blokiem "Wiecej" (<!--more-->) jest zwiniete
      w przycisk "Czytaj wiecej" - tresc zostaje w kodzie strony. Na stronach jachtow automatycznie: stara tresc pod nowym szablonem.
   i) Waskie twarde spacje (U+202F) -> zwykle spacje. */
function marigo_tekst_dl( $h ) {
	$t = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' ) ) );
	return function_exists( 'mb_strlen' ) ? mb_strlen( $t, 'UTF-8' ) : strlen( $t );
}

/* odstepy przy znakach interpunkcyjnych (punkt 11 l) - tekst bez znacznikow HTML */
function marigo_interpunkcja( $n ) {
	$n = preg_replace( '/(?<=[\p{L}\p{N})%"”])[\s\x{00A0}]+(?=[,.!?:;](?:\s|$|\p{L}))/u', '', $n );
	$n = preg_replace( '/(?<=[\p{L}\p{N}]):(?=\p{L}{2})/u', ': ', $n );
	$n = preg_replace( '/(?<=\p{Ll}{2})([.,!?…])(?=\p{Lu}\p{Ll})/u', '$1 ', $n );
	$n = preg_replace( '/(^|\s)[”"][\s\x{00A0}]+(?=\p{L})/u', '$1„', $n );
	$n = preg_replace( '/(?<=\p{L}{2}),(?=\p{L})/u', ', ', $n );
	$n = preg_replace( '/(?<=\p{L}{2});(?=\p{L})/u', '; ', $n );
	// numeracja punktow sklejona z tekstem: "1.W rejs" -> "1. W rejs"
	$n = preg_replace( '/(^|\s)(\d{1,2})\.(?=\p{Lu}(?:\p{Ll}|\s))/u', '$1$2. ', $n );
	$n = preg_replace( '/\([ \x{00A0}]+/u', '(', $n );
	$n = preg_replace( '/[ \x{00A0}]+\)/u', ')', $n );
	$n = preg_replace( '/(?<=\p{L}{2})\((?=\p{L}|$)/u', ' (', $n );
	$n = preg_replace( '/(?<=[\p{L}\p{N}])[-–](?=[ \x{00A0}]+(?:[\p{L}\p{N}]|$))/u', ' -', $n );
	$n = preg_replace( '/(?<=[ \x{00A0}])[-–](?=\p{L}{2})/u', '- ', $n );
	$n = preg_replace( '/(?<=\S) {2,}(?=\S)/u', ' ', $n );
	// zwykly myslnik zamiast polpauzy i pauzy
	$n = str_replace( array( '–', '—' ), '-', $n );
	// polskie cudzyslowy: otwierajacy „ (zamiast ” lub " na poczatku slowa), zamykajacy ”
	$n = preg_replace( '/(^|[\s(\x{00A0}])["”“](?=[\p{L}\p{N}])/u', '$1„', $n );
	$n = preg_replace( '/(?<=[\p{L}\p{N}.!?…)])"(?=[\s,.;:!?)]|$)/u', '”', $n );
	// dolny cudzyslow wpisany na koncu cytatu („...„) -> zamykajacy
	$n = preg_replace( '/(?<=[\p{L}\p{N}.!?…)])„(?=[\s,.;:!?)]|$)/u', '”', $n );
	$n = preg_replace( '/^„(?=[\s,.;:!?)])/u', '”', $n );
	// v8: "PLN" zostaje jak w tekscie klientki (bez zamiany na "zł")
	return $n;
}
/* zajawki wpisow na liscie bloga: te same poprawki odstepow */
add_filter( 'get_the_excerpt', function ( $t ) {
	$czesci = preg_split( '/(<[^>]*>)/', (string) $t, -1, PREG_SPLIT_DELIM_CAPTURE );
	foreach ( $czesci as $k => $c ) { if ( '' !== $c && '<' !== $c[0] ) { $czesci[ $k ] = marigo_interpunkcja( $c ); } }
	return implode( '', $czesci );
}, 20 );

function marigo_porzadki( $html ) {
	$html = str_replace( "\xE2\x80\xAF", ' ', $html );
	// j) stare linki, ktore dzis przekierowuja (albo trafiaja na strone glowna) -> prosto na wlasciwa podstrone
	$przek = array(
		'czarter-bez-patentu' => '/czarter-jachtow-motorowych-mazury/bez-patentu/',
		'bez-patentu'         => '/czarter-jachtow-motorowych-mazury/bez-patentu/',
		'jachty'              => '/zaglowki/',
		'jachty-zaglowe'      => '/zaglowki/',
		'antila-33'           => '/jachty/antila-33-mazury/',
		'last-minute'         => '/home/czarter-jachtow-mazury-last-minute/',
		'szanty-wegorzewo-2018' => '/szanty-wegorzewo/',
	);
	$html = preg_replace_callback( '#href="https?://(?:www\.)?marigo\.pl/(czarter-bez-patentu|bez-patentu|jachty|jachty-zaglowe|antila-33|last-minute|szanty-wegorzewo-2018)/?(\#[^"]*)?"#i', function ( $m ) use ( $przek ) {
		return 'href="' . esc_url( home_url( $przek[ strtolower( $m[1] ) ] ) ) . ( isset( $m[2] ) ? $m[2] : '' ) . '"';
	}, $html );
	$dodaj_klase = function ( $atr, $klasa ) {
		if ( preg_match( '/\sclass="[^"]*"/i', $atr ) ) {
			return preg_replace( '/\sclass="([^"]*)"/i', ' class="$1 ' . $klasa . '"', $atr, 1 );
		}
		return $atr . ' class="' . $klasa . '"';
	};
	// a)
	$html = preg_replace_callback( '#<h([2-6])((?:\s[^>]*)?)>(.*?)</h\1>#si', function ( $m ) use ( $dodaj_klase ) {
		if ( marigo_tekst_dl( $m[3] ) < 140 ) { return $m[0]; }
		return '<h' . $m[1] . $dodaj_klase( $m[2], 'mgx-dlugi' ) . '>' . $m[3] . '</h' . $m[1] . '>';
	}, $html );
	// b)
	$html = preg_replace_callback( '#<p(\s[^>]*class="[^"]*gb-headline[^"]*"[^>]*)>(.*?)</p>(\s*<h[2-4][\s>])#si', function ( $m ) use ( $dodaj_klase ) {
		$klasa = marigo_tekst_dl( $m[2] ) <= 20 ? 'mgx-ukryj' : 'mgx-nad';
		$t = html_entity_decode( wp_strip_all_tags( $m[2] ), ENT_QUOTES, 'UTF-8' );
		$duze = preg_match_all( '/\p{Lu}/u', $t ); $wsz = preg_match_all( '/\p{L}/u', $t );
		if ( 'mgx-nad' === $klasa && $wsz && $duze / $wsz > 0.6 ) { $klasa .= ' mgx-nad-wers'; }
		return '<p' . $dodaj_klase( $m[1], $klasa ) . '>' . $m[2] . '</p>' . $m[3];
	}, $html );
	// e) podwojne <br> i punktory "•"
	$html = preg_replace_callback( '#<p((?:\s[^>]*)?)>((?:(?!</?p[\s>]).)*?<br\s*/?>(?:(?!</?p[\s>]).)*?)</p>#si', function ( $m ) {
		$atr = $m[1];
		$sp = '(?:\s|&nbsp;|\xC2\xA0)*';
		$w = preg_replace( '#<br\s*/?>' . $sp . '(</(?:strong|b|em)>)?' . $sp . '(?:<br\s*/?>' . $sp . ')+#i', '$1</p><p' . $atr . '>', $m[2] );
		$w = '<p' . $atr . '>' . $w . '</p>';
		$w = preg_replace( '#<p([^>]*)>' . $sp . '(?:<br\s*/?>' . $sp . ')+#i', '<p$1>', $w );
		$w = preg_replace( '#(?:' . $sp . '<br\s*/?>)+' . $sp . '</p>#i', '</p>', $w );
		$w = preg_replace( '#<p[^>]*>\s*(?:&nbsp;|\xC2\xA0)?\s*</p>#i', '', $w );
		// punktory
		return preg_replace_callback( '#<p([^>]*)>((?:(?!</p>).)*)</p>#s', function ( $p ) {
			$linie = preg_split( '#<br\s*/?>#i', $p[2] );
			$pkt = 0;
			foreach ( $linie as $l ) { if ( preg_match( '/^\s*(?:<[^>]+>\s*)*•/u', $l ) ) { $pkt++; } }
			if ( $pkt < 2 ) { return $p[0]; }
			$przed = array(); $li = array();
			foreach ( $linie as $l ) {
				if ( preg_match( '/^\s*(?:<[^>]+>\s*)*•/u', $l ) ) { $li[] = '<li>' . trim( preg_replace( '/•\s*/u', '', $l, 1 ) ) . '</li>'; }
				elseif ( ! $li ) { $przed[] = $l; }
				else { $li[ count( $li ) - 1 ] = substr( $li[ count( $li ) - 1 ], 0, -5 ) . '<br>' . $l . '</li>'; }
			}
			$wynik = trim( implode( '<br>', $przed ) ) !== '' ? '<p' . $p[1] . '>' . implode( '<br>', $przed ) . '</p>' : '';
			return $wynik . '<ul class="mgx-pkt">' . implode( '', $li ) . '</ul>';
		}, $w );
	}, $html );
	return $html;
}

function marigo_czy_rabat( $src ) {
	if ( preg_match( '#/discount(\d{1,2})[^/]*\.(?:png|jpe?g|webp|gif)#i', $src, $m ) ) { return (int) $m[1]; }
	if ( preg_match( '#/[^/]*?(\d{1,2})[-_]?procent[^/]*rabat[^/]*\.(?:png|jpe?g|webp|gif)#i', $src, $m ) ) { return (int) $m[1]; }
	if ( preg_match( '#/[^/]*rabat[^/]*?(\d{1,2})[^/]*\.(?:png|jpe?g|webp|gif)#i', $src, $m ) ) { return (int) $m[1]; }
	return 0;
}

function marigo_przetworz_dom( $html, $czytaj ) {
	if ( ! class_exists( 'DOMDocument' ) ) { return $html; }
	$dom = marigo_dom( $html );
	$root = $dom->getElementById( 'mgx-root' );
	if ( ! $root ) { return $html; }
	$xp = new DOMXPath( $dom );
	$wstaw = array();

	// d) rabaty
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'img' ) ) as $im ) {
		$proc = marigo_czy_rabat( $im->getAttribute( 'src' ) . ' ' . $im->getAttribute( 'data-src' ) );
		if ( ! $proc ) { continue; }
		$blok = $im->parentNode;
		while ( $blok && $blok !== $root && ! in_array( strtolower( $blok->nodeName ), array( 'p', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'td', 'figure', 'div' ), true ) ) { $blok = $blok->parentNode; }
		$cel = $im;
		if ( $im->parentNode && 'a' === strtolower( $im->parentNode->nodeName ) && 1 === $im->parentNode->childNodes->length ) { $cel = $im->parentNode; }
		if ( $blok && 'figure' === strtolower( $blok->nodeName ) ) {
			$blok->parentNode->removeChild( $blok );
			continue;
		}
		// jesli tuz przed obrazkiem w tekscie stoi juz ten sam procent ("Rabat 10 %"), obrazek znika bez plakietki
		$przed = '';
		for ( $w = $cel->previousSibling; $w && strlen( $przed ) < 40; $w = $w->previousSibling ) { $przed = $w->textContent . $przed; }
		if ( preg_match( '/(?<!\d)' . $proc . '\s*%\s*$/u', trim( str_replace( "\xC2\xA0", ' ', $przed ) ) ) ) {
			$cel->parentNode->replaceChild( $dom->createTextNode( ' ' ), $cel );
		} else {
			$s = $dom->createElement( 'span', '-' . $proc . '%' );
			$s->setAttribute( 'class', 'mgx-rabat' );
			$cel->parentNode->replaceChild( $s, $cel );
			$s->parentNode->insertBefore( $dom->createTextNode( ' ' ), $s );
			if ( $s->nextSibling ) { $s->parentNode->insertBefore( $dom->createTextNode( ' ' ), $s->nextSibling ); } else { $s->parentNode->appendChild( $dom->createTextNode( ' ' ) ); }
		}
		// ramka promocji tylko dla krotkiego akapitu o rabacie; w dlugim akapicie zostaje sama plakietka
		if ( $blok && $blok !== $root && in_array( strtolower( $blok->nodeName ), array( 'p', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) && ( marigo_tekst_dl( $blok->textContent ) <= 380 || false !== stripos( substr( $blok->textContent, 0, 90 ), 'promocj' ) ) ) { marigo_dodaj_klase( $blok, 'mgx-promo' ); }
	}

	// c) stare kafelki jachtow -> karty ze strony glownej
	foreach ( iterator_to_array( $xp->query( '//div[contains(concat(" ", normalize-space(@class), " "), " gb-grid-wrapper ")]' ) ) as $gw ) {
		if ( ! $gw->parentNode ) { continue; }
		$sciezki = array(); $ok = 0; $kol = 0;
		foreach ( $gw->childNodes as $c ) {
			if ( ! ( $c instanceof DOMElement ) ) { continue; }
			$kol++;
			$h2 = $xp->query( './/h2//a[@href]', $c );
			if ( $xp->query( './/figure', $c )->length && $h2->length && $xp->query( './/h6', $c )->length ) {
				$ok++;
				$sciezki[] = marigo_sciezka( $h2->item( 0 )->getAttribute( 'href' ) );
			}
		}
		if ( $ok < 2 || $ok !== $kol ) { continue; }
		$flota = marigo_flota_html( '', $sciezki );
		if ( '' === $flota ) { continue; }
		$token = 'MGXWSTAW' . count( $wstaw ) . 'X';
		$wstaw[ $token ] = $flota;
		$gw->parentNode->replaceChild( $dom->createTextNode( $token ), $gw );
	}

	// k) adres e-mail zapisany zwyklym tekstem -> link mailto
	foreach ( iterator_to_array( $xp->query( '//text()[contains(., "@") and not(ancestor::a) and not(ancestor::script) and not(ancestor::style) and not(ancestor::textarea)]' ) ) as $tn ) {
		$cz = preg_split( '/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})/', $tn->nodeValue, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( count( $cz ) < 3 ) { continue; }
		$frag = $dom->createDocumentFragment();
		foreach ( $cz as $i => $c ) {
			if ( $i % 2 ) { $a = $dom->createElement( 'a' ); $a->setAttribute( 'href', 'mailto:' . $c ); $a->appendChild( $dom->createTextNode( $c ) ); $frag->appendChild( $a ); }
			elseif ( '' !== $c ) { $frag->appendChild( $dom->createTextNode( $c ) ); }
		}
		$tn->parentNode->replaceChild( $frag, $tn );
	}

	// l) odstepy przy znakach interpunkcyjnych w starych tekstach (sam wyglad slow, tresc bez zmian):
	//    spacja przed , . ! ? : ; i po "(" / przed ")" usuwana, brakujaca spacja po kropce/przecinku miedzy slowami dodawana,
	//    myslnik przyklejony do jednego slowa ("slowo- slowo", "2027– przy") dostaje spacje z obu stron, podwojne spacje pojedyncze
	foreach ( iterator_to_array( $xp->query( '//text()[not(ancestor::script) and not(ancestor::style) and not(ancestor::code) and not(ancestor::textarea)]' ) ) as $tn ) {
		$v = $tn->nodeValue;
		if ( '' === trim( $v ) ) { continue; }
		$n = marigo_interpunkcja( $v );
		// tekst zaczynajacy sie od " ," / " :" tuz po pogrubieniu lub linku
		if ( $tn->previousSibling ) {
			$n = preg_replace( '/^[ \x{00A0}]+(?=[,.!?:;](?:\s|$))/u', '', $n );
			// "<strong>2027</strong>– przy" -> "2027 - przy"
			if ( preg_match( '/\S$/u', $tn->previousSibling->textContent ) ) { $n = preg_replace( '/^[-–](?=[ \x{00A0}]+\p{L})/u', ' -', $n ); }
		}
		// spacje wokol plakietki rabatu i podwojne spacje na styku elementow
		$n = preg_replace( '/[ \x{00A0}]{2,}/u', ' ', $n );
		// poczatek akapitu / punktu listy bez spacji
		if ( null === $tn->previousSibling && $tn->parentNode && in_array( strtolower( $tn->parentNode->nodeName ), array( 'p', 'li', 'td', 'h2', 'h3', 'h4' ), true ) ) { $n = preg_replace( '/^[\s\x{00A0}]+/u', '', $n ); }
		if ( $n !== $v ) { $tn->nodeValue = $n; }
	}

	// l2) te same poprawki na styku dwoch fragmentow tekstu (np. "slowo</strong>(", "obtluczen-</strong> konieczne", "posiadamy.<a>Wynajem")
	$blok_tekstu = function ( $n ) {
		for ( $e = $n->parentNode; $e && $e instanceof DOMElement; $e = $e->parentNode ) {
			if ( in_array( strtolower( $e->nodeName ), array( 'p', 'li', 'td', 'th', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'pre', 'figcaption', 'summary', 'div', 'blockquote' ), true ) ) { return $e; }
		}
		return null;
	};
	foreach ( iterator_to_array( $xp->query( '//text()[not(ancestor::script) and not(ancestor::style) and not(ancestor::textarea)]' ) ) as $tn ) {
		$pr = $xp->query( 'preceding::text()[1]', $tn )->item( 0 );
		if ( ! $pr || $blok_tekstu( $pr ) !== $blok_tekstu( $tn ) ) { continue; }
		$a = $pr->nodeValue; $b = $tn->nodeValue;
		if ( '' === $a || '' === $b ) { continue; }
		$a2 = $a; $b2 = $b;
		if ( preg_match( '/\p{L}$/u', $a2 ) && preg_match( '/^\((?:\p{L}|$)/u', $b2 ) ) { $b2 = ' ' . $b2; }
		if ( preg_match( '/[\s\x{00A0}]$/u', $a2 ) && preg_match( '/^[,.!?:;](?:\s|$|\p{L})/u', $b2 ) ) { $a2 = rtrim( $a2, " \t\n\r\xC2\xA0" ); }
		if ( preg_match( '/[\p{L}\p{N}][-–]$/u', $a2 ) && preg_match( '/^[\s\x{00A0}]+[\p{L}\p{N}]/u', $b2 ) ) { $a2 = preg_replace( '/[-–]$/u', ' -', $a2 ); }
		if ( preg_match( '/\p{Ll}{2}[.,]$/u', $a2 ) && preg_match( '/^\p{L}/u', $b2 ) ) { $a2 .= ' '; }
		if ( preg_match( '/\p{Ll}{2}$/u', $a2 ) && preg_match( '/^[.,](?=\p{Lu}\p{Ll})/u', $b2 ) ) { $b2 = preg_replace( '/^([.,])/u', '$1 ', $b2 ); }
		if ( preg_match( '/^[ \x{00A0}]*:\S/u', $b2 ) && preg_match( '/\S$/u', $a2 ) ) { $b2 = preg_replace( '/^([ \x{00A0}]*:)/u', ': ', ltrim( $b2 ) ); }
		if ( preg_match( '/\($/u', $a2 ) ) { $b2 = preg_replace( '/^[\s\x{00A0}]+/u', '', $b2 ); }
		if ( preg_match( '/^\)/u', $b2 ) ) { $a2 = rtrim( $a2, " \t\n\r\xC2\xA0" ); }
		if ( $a2 !== $a ) { $pr->nodeValue = $a2; }
		if ( $b2 !== $b ) { $tn->nodeValue = $b2; }
	}

	// f) calkowicie pogrubione akapity i punkty listy
	foreach ( iterator_to_array( $xp->query( '//p | //li' ) ) as $p ) {
		if ( $p instanceof DOMElement && preg_match( '/(^|\s)mg-/', (string) $p->getAttribute( 'class' ) ) ) { continue; }
		$caly = trim( preg_replace( '/\s+/u', ' ', $p->textContent ) );
		if ( '' === $caly ) { continue; }
		$bold = '';
		foreach ( $xp->query( './/strong | .//b', $p ) as $s ) {
			if ( ! $xp->query( 'ancestor::strong | ancestor::b', $s )->length || $s->parentNode === $p ) { $bold .= ' ' . $s->textContent; }
		}
		$bold = trim( preg_replace( '/\s+/u', ' ', $bold ) );
		$dl = function_exists( 'mb_strlen' ) ? mb_strlen( $caly, 'UTF-8' ) : strlen( $caly );
		$bdl = function_exists( 'mb_strlen' ) ? mb_strlen( $bold, 'UTF-8' ) : strlen( $bold );
		if ( $bdl < $dl * 0.9 ) { continue; }
		if ( 'p' === strtolower( $p->nodeName ) && $dl <= 90 ) { marigo_dodaj_klase( $p, 'mgx-podtytul' ); }
		elseif ( $dl > 90 ) { marigo_dodaj_klase( $p, 'mgx-bez-bold' ); }
	}

	// g) YouTube
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'iframe' ) ) as $f ) {
		if ( ! preg_match( '#youtube(?:-nocookie)?\.com/embed/([A-Za-z0-9_-]{6,})#', $f->getAttribute( 'src' ) . ' ' . $f->getAttribute( 'data-src' ), $m ) ) { continue; }
		$id = $m[1];
		$tyt = $f->getAttribute( 'title' ) ? $f->getAttribute( 'title' ) : 'Film Marigo Czarter';
		$a = $dom->createElement( 'a' );
		$a->setAttribute( 'class', 'mgx-yt' );
		$a->setAttribute( 'href', 'https://www.youtube.com/watch?v=' . $id );
		$a->setAttribute( 'data-id', $id );
		$a->setAttribute( 'aria-label', 'Odtwórz film: ' . $tyt );
		$im = $dom->createElement( 'img' );
		$im->setAttribute( 'src', 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg' );
		$im->setAttribute( 'alt', '' );
		$im->setAttribute( 'width', '480' );
		$im->setAttribute( 'height', '360' );
		$im->setAttribute( 'loading', 'lazy' );
		$im->setAttribute( 'decoding', 'async' );
		$a->appendChild( $im );
		$pl = $dom->createElement( 'span' );
		$pl->setAttribute( 'class', 'mgx-yt-play' );
		$a->appendChild( $pl );
		$f->parentNode->replaceChild( $a, $f );
		$GLOBALS['marigo_yt'] = true;
	}
	// blok YouTube, ktorego WordPress nie zamienil na odtwarzacz (w kodzie zostal sam adres filmu) - ten sam lekki podglad
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'div' ) ) as $w ) {
		if ( false === strpos( ' ' . $w->getAttribute( 'class' ) . ' ', ' wp-block-embed__wrapper ' ) || $w->getElementsByTagName( 'iframe' )->length || $w->getElementsByTagName( 'a' )->length > 1 ) { continue; }
		if ( ! preg_match( '#^\s*https?://(?:www\.)?(?:youtube\.com/watch\?v=|youtu\.be/)([A-Za-z0-9_-]{11})\S*\s*$#', $w->textContent, $m ) ) { continue; }
		$id = $m[1];
		while ( $w->firstChild ) { $w->removeChild( $w->firstChild ); }
		$a = $dom->createElement( 'a' );
		$a->setAttribute( 'class', 'mgx-yt' );
		$a->setAttribute( 'href', 'https://www.youtube.com/watch?v=' . $id );
		$a->setAttribute( 'data-id', $id );
		$a->setAttribute( 'aria-label', 'Odtwórz film Marigo Czarter' );
		$im = $dom->createElement( 'img' );
		$im->setAttribute( 'src', 'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg' );
		$im->setAttribute( 'alt', '' );
		$im->setAttribute( 'width', '480' );
		$im->setAttribute( 'height', '360' );
		$im->setAttribute( 'loading', 'lazy' );
		$im->setAttribute( 'decoding', 'async' );
		$a->appendChild( $im );
		$pl = $dom->createElement( 'span' );
		$pl->setAttribute( 'class', 'mgx-yt-play' );
		$a->appendChild( $pl );
		$w->appendChild( $a );
		$GLOBALS['marigo_yt'] = true;
	}

	// g1) osadzone wpisy WordPressa (ramka z podgladem innego wpisu): zostaje sam link w ramce, bez ciezkiej ramki iframe
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'iframe' ) ) as $f ) {
		if ( marigo_ma_klase( $f, 'wp-embedded-content' ) ) { $f->parentNode->removeChild( $f ); }
	}

	// g2) mapa Google: zamiast ciezkiej ramki od razu - przycisk "Pokaz mape dojazdu" (mapa laduje sie po kliknieciu)
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'iframe' ) ) as $f ) {
		$src = $f->getAttribute( 'src' ) ? $f->getAttribute( 'src' ) : $f->getAttribute( 'data-src' );
		if ( false === strpos( $src, 'google.com/maps' ) ) { continue; }
		$d = $dom->createElement( 'div' );
		$d->setAttribute( 'class', 'mgx-mapa' );
		$b = $dom->createElement( 'button', 'Pokaż mapę dojazdu' );
		$b->setAttribute( 'type', 'button' );
		$b->setAttribute( 'class', 'mgx-mapa-btn' );
		$b->setAttribute( 'data-src', $src );
		$d->appendChild( $b );
		$p = $dom->createElement( 'span', 'Port Sztynort, Sztynort Duży 11, 11-600 Węgorzewo' );
		$p->setAttribute( 'class', 'mgx-mapa-adr' );
		$d->appendChild( $p );
		$f->parentNode->replaceChild( $d, $f );
		$GLOBALS['marigo_yt'] = true;
	}

	// h) "Czytaj wiecej"
	if ( $czytaj ) {
		$znacznik = null;
		$more = $xp->query( '//span[starts-with(@id, "more-")]' );
		if ( $more->length ) {
			$znacznik = $more->item( 0 );
			$pp = $znacznik->parentNode;
			if ( $pp && 'p' === strtolower( $pp->nodeName ) && '' === trim( $pp->textContent ) && $pp !== $root ) { $znacznik = $pp; }
		} elseif ( 'jacht' === $czytaj ) {
			// strona jachtu: wszystko pod ostatnia sekcja nowego szablonu
			$ost = null;
			foreach ( $root->childNodes as $c ) { if ( marigo_ma_klase( $c, 'mg-jsek' ) ) { $ost = $c; } }
			if ( $ost ) {
				$nast = $ost->nextSibling;
				while ( $nast && ! ( $nast instanceof DOMElement ) ) { $nast = $nast->nextSibling; }
				if ( $nast ) { $znacznik = $dom->createElement( 'span' ); $root->insertBefore( $znacznik, $nast ); }
			}
		}
		if ( $znacznik ) {
			$przenies = array();
			$wezel = $znacznik;
			while ( $wezel && $wezel !== $root && $wezel->parentNode ) {
				for ( $s = $wezel->nextSibling; $s; $s = $s->nextSibling ) { $przenies[] = $s; }
				if ( $wezel->parentNode === $root ) { break; }
				$wezel = $wezel->parentNode;
			}
			$tekst = 0;
			foreach ( $przenies as $s ) { $tekst += strlen( trim( $s->textContent ) ); }
			if ( $tekst > 400 ) {
				$d = $dom->createElement( 'details' );
				$d->setAttribute( 'class', 'mgx-czytaj' );
				$sm = $dom->createElement( 'summary' );
				$o = $dom->createElement( 'span', 'Czytaj więcej' );
				$o->setAttribute( 'class', 'mgx-cz-o' );
				$z = $dom->createElement( 'span', 'Zwiń' );
				$z->setAttribute( 'class', 'mgx-cz-z' );
				$sm->appendChild( $o );
				$sm->appendChild( $z );
				$d->appendChild( $sm );
				$in = $dom->createElement( 'div' );
				$in->setAttribute( 'class', 'mgx-czytaj-in' );
				foreach ( $przenies as $s ) { $in->appendChild( $s ); }
				$d->appendChild( $in );
				if ( $wezel->nextSibling ) { $root->insertBefore( $d, $wezel->nextSibling ); } else { $root->appendChild( $d ); }
			}
			if ( $znacznik->parentNode ) { $znacznik->parentNode->removeChild( $znacznik ); }
		}
	}

	$out = marigo_dom_html( $dom );
	return $wstaw ? strtr( $out, $wstaw ) : $out;
}

add_filter( 'the_content', function ( $html ) {
	if ( ! is_singular() || ! in_the_loop() ) { return $html; }
	$html = marigo_porzadki( $html );
	$czytaj = false;
	if ( is_page() && ! is_front_page() ) { $czytaj = marigo_tresc_zawiera( 'mg-jhero' ) ? ( marigo_tresc_zawiera( 'm9-' ) ? false : 'jacht' ) : 'strona'; }
	return marigo_przetworz_dom( $html, $czytaj );
}, 20 );

/* szerokie tabele (cennik) na telefonie: napis "Przesuń tabelę w bok" i zanikanie przy prawej krawedzi, znikaja po przewinieciu */
add_action( 'wp_footer', function () {
	if ( ! is_singular() ) { return; }
	echo '<script>(function(){var tel=window.innerWidth<768;document.querySelectorAll(\'.entry-content .wp-block-table\').forEach(function(f){var t=f.querySelector(\'table\');if(!t)return;var cen=f.classList.contains(\'mg-cennik-tabela\');[].forEach.call(t.rows,function(r){if(!r.textContent.trim()&&!r.querySelector(\'img\'))r.style.display=\'none\'});[].forEach.call(t.querySelectorAll(\'td\'),function(c){if(/^\+?[\d\s()\-]{7,}$/.test(c.textContent.trim()))c.classList.add(\'mgx-nr\')});if(f.scrollWidth<=f.clientWidth+4)return;var w=t.rows;if(cen){}else if(tel&&w.length===1&&w[0].cells.length>=4&&w[0].cells.length%2===0){f.classList.add(\'mgx-pary\');}else if(tel&&w.length>=2&&w[0].cells.length>=3){var h=t.tHead&&t.tHead.rows.length?t.tHead.rows[0]:w[0];if(h===w[0])h.classList.add(\'mgx-nagl\');var n=[].map.call(h.cells,function(c){return c.textContent.trim()});[].forEach.call(w,function(r){if(r===h)return;[].forEach.call(r.cells,function(c,k){if(n[k])c.setAttribute(\'data-label\',n[k])})});f.classList.add(\'mgx-karty\');}if(f.scrollWidth<=f.clientWidth+4)return;f.classList.add(\'mgx-przewin\');var p=document.createElement(\'p\');p.className=\'mgx-przesun\';p.textContent=\'Przesuń tabelę w bok\';f.parentNode.insertBefore(p,f);f.addEventListener(\'scroll\',function(){if(f.scrollLeft>20){p.classList.add(\'mgx-ukryte\');}f.classList.toggle(\'mgx-koniec\',f.scrollLeft+f.clientWidth>=f.scrollWidth-4)},{passive:true})})})();</script>';
}, 60 );

/* filmy YouTube i mapa Google: ladowane dopiero po kliknieciu */
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['marigo_yt'] ) ) { return; }
	echo "<script>document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a.mgx-yt');if(!a)return;e.preventDefault();var f=document.createElement('iframe');f.src='https://www.youtube-nocookie.com/embed/'+a.getAttribute('data-id')+'?autoplay=1&rel=0';f.title=a.getAttribute('aria-label');f.allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';f.allowFullscreen=true;f.className='mgx-yt-f';a.parentNode.replaceChild(f,a)});document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('.mgx-mapa-btn');if(!b)return;var f=document.createElement('iframe');f.src=b.getAttribute('data-src');f.title='Mapa dojazdu do portu Sztynort';f.className='mgx-mapa-f';f.setAttribute('allowfullscreen','');f.setAttribute('referrerpolicy','no-referrer-when-downgrade');var d=b.parentNode;d.parentNode.replaceChild(f,d)});</script>";
}, 60 );

/* ---------- 12. cennik z przelacznikiem jachtu, last minute jako karty ---------- */
/* /cennik/: tabele cen (edytowane jak dotad blokiem Tabela) stoja w grupie z klasa "mg-cennik-zrodlo".
   Na stronie w ich miejscu wyswietla sie przelacznik jachtu i tabela TYLKO wybranego jachtu (Termin | Doba | 7 dob).
   Bez JavaScriptu widac wszystkie jachty jeden pod drugim. Ceny na kartach i stronach jachtow czytane sa z tych samych tabel.
   /home/czarter-jachtow-mazury-last-minute/: tabela ofert w grupie "mg-lastminute" wyswietla sie jako karty ofert. */

/* nazwy jachtow z kart strony glownej: nazwa => [sciezka, typ] */
function marigo_jachty_z_kart() {
	$w = array();
	foreach ( marigo_karty() as $k ) {
		if ( preg_match( '#<h3[^>]*>.*?<a[^>]*>(.*?)</a>#s', $k['html'], $m ) ) {
			$w[ trim( html_entity_decode( wp_strip_all_tags( $m[1] ), ENT_QUOTES, 'UTF-8' ) ) ] = array( $k['sciezka'], $k['typ'] );
		}
	}
	return $w;
}

/* jachty wymienione w naglowku kolumny cennika ("Antila 33.1 Antila 33.3" = dwa jachty) */
function marigo_jachty_kolumny( $naglowek, $jachty ) {
	$znalezione = array();
	foreach ( $jachty as $nazwa => $dane ) {
		$wz = '/(?<![\p{L}\p{N}.])' . preg_quote( $nazwa, '/' ) . '(?![\p{L}\p{N}.])/iu';
		$wz2 = '/^' . preg_quote( trim( $naglowek ), '/' ) . '(?![\p{N}.])/iu';
		if ( preg_match( $wz, $naglowek ) || preg_match( $wz2, $nazwa ) ) { $znalezione[ $nazwa ] = $dane; }
	}
	return $znalezione;
}

function marigo_cennik_przelacznik_html() {
	$tabele = marigo_tabele_cennika();
	if ( ! $tabele ) { return ''; }
	$jachty = marigo_jachty_z_kart();
	$grupy = array( 'zaglowe' => array(), 'motorowe' => array() );
	$panele = '';
	$n = 0;
	foreach ( $tabele as $ti => $t ) {
		foreach ( $t[0] as $i => $nagl ) {
			if ( 0 === $i || '' === trim( $nagl ) ) { continue; }
			$n++;
			$id = 'mg-cp-' . $n;
			$nazwy = marigo_jachty_kolumny( $nagl, $jachty );
			$typ = $nazwy ? reset( $nazwy )[1] : ( 0 === $ti ? 'zaglowe' : 'motorowe' );
			$tytul = $nazwy ? implode( ' i ', array_keys( $nazwy ) ) : $nagl;
			$grupy[ $typ ][] = '<button type="button" class="mg-cp-pig" data-cel="' . $id . '" aria-controls="' . $id . '">' . esc_html( $tytul ) . '</button>';
			$linki = '';
			foreach ( $nazwy as $nazwa => $dane ) {
				$linki .= '<a class="mg-cp-link" href="' . esc_url( home_url( '/' . $dane[0] . '/' ) ) . '">Zobacz jacht ' . esc_html( $nazwa ) . '</a>';
			}
			$uwaga = trim( $t[0][0] );
			$uwaga = function_exists( 'mb_strtolower' ) ? mb_strtolower( $uwaga, 'UTF-8' ) : strtolower( $uwaga );
			$panele .= '<section class="mg-cp-panel" id="' . $id . '" aria-label="Cennik ' . esc_attr( $tytul ) . '">'
				. '<h3 class="mg-cp-nazwa">' . esc_html( $tytul ) . '</h3>'
				. ''
				. marigo_cennik_tabela_html( $t, $i, true, false )
				. ( $linki ? '<p class="mg-cp-linki">' . $linki . '</p>' : '' )
				. '</section>';
		}
	}
	$nazwy_grup = array( 'zaglowe' => 'Jachty żaglowe', 'motorowe' => 'Jachty motorowe' );
	$pigulki = '';
	foreach ( $grupy as $g => $przyciski ) {
		if ( ! $przyciski ) { continue; }
		$pigulki .= '<div class="mg-cp-grupa"><p class="mg-cp-gtyt">' . $nazwy_grup[ $g ] . '</p><div class="mg-cp-pigulki">' . implode( '', $przyciski ) . '</div></div>';
	}
	$GLOBALS['marigo_cp'] = true;
	return '<div class="mg-cp"><div class="mg-cp-wybor" role="group" aria-label="Wybierz jacht">' . $pigulki . '</div><div class="mg-cp-panele">' . $panele . '</div></div>';
}

/* last minute: wiersze tabeli -> karty ofert */
function marigo_lastminute_html( $tabela, $xp ) {
	$wiersze = array();
	foreach ( $xp->query( './/tr', $tabela ) as $tr ) {
		$kom = array();
		foreach ( $tr->childNodes as $c ) {
			if ( $c instanceof DOMElement && in_array( strtolower( $c->nodeName ), array( 'td', 'th' ), true ) ) { $kom[] = $c; }
		}
		if ( $kom ) { $wiersze[] = $kom; }
	}
	if ( count( $wiersze ) < 1 ) { return ''; }
	$kol = array();
	foreach ( $wiersze[0] as $i => $c ) {
		$t = mb_strtolower( trim( $c->textContent ), 'UTF-8' );
		if ( false !== strpos( $t, 'jacht' ) ) { $kol['jacht'] = $i; }
		elseif ( false !== strpos( $t, 'termin' ) ) { $kol['termin'] = $i; }
		elseif ( false !== strpos( $t, 'długo' ) || false !== strpos( $t, 'dni' ) ) { $kol['dl'] = $i; }
		elseif ( false !== strpos( $t, 'last' ) ) { $kol['lm'] = $i; }
		elseif ( false !== strpos( $t, 'cena' ) ) { $kol['std'] = $i; }
	}
	$cena = function ( $v ) {
		$v = trim( preg_replace( '/\s+/u', ' ', $v ) );
		$l = preg_replace( '/[^0-9]/', '', $v );
		return '' !== $l ? number_format( (int) $l, 0, ',', ' ' ) . ' zł' : $v;
	};
	$karty = '';
	for ( $r = 1; $r < count( $wiersze ); $r++ ) {
		$w = $wiersze[ $r ];
		$g = function ( $k ) use ( $w, $kol ) { return isset( $kol[ $k ], $w[ $kol[ $k ] ] ) ? trim( preg_replace( '/\s+/u', ' ', $w[ $kol[ $k ] ]->textContent ) ) : ''; };
		$jacht = $g( 'jacht' );
		if ( '' === $jacht ) { continue; }
		// v8: oferta, ktorej termin juz minal (ostatnia data "dd.mm.rrrr" w kolumnie Termin), nie jest pokazywana
		if ( preg_match_all( '/(\d{1,2})\.(\d{1,2})\.(\d{4})/', $g( 'termin' ), $dd, PREG_SET_ORDER ) ) {
			$o = end( $dd );
			if ( mktime( 23, 59, 0, (int) $o[2], (int) $o[1], (int) $o[3] ) < current_time( 'timestamp' ) ) { continue; }
		}
		$href = '';
		if ( isset( $kol['jacht'] ) ) {
			foreach ( $w[ $kol['jacht'] ]->getElementsByTagName( 'a' ) as $a ) { $href = $a->getAttribute( 'href' ); break; }
		}
		$temat = rawurlencode( 'Last minute: ' . $jacht . ', ' . $g( 'termin' ) );
		$karty .= '<article class="mg-lm-karta">'
			. '<h3 class="mg-lm-jacht">' . ( $href ? '<a href="' . esc_url( $href ) . '">' . esc_html( $jacht ) . '</a>' : esc_html( $jacht ) ) . '</h3>'
			. '<p class="mg-lm-termin">' . esc_html( $g( 'termin' ) ) . ( $g( 'dl' ) ? ' <span>· ' . esc_html( $g( 'dl' ) ) . '</span>' : '' ) . '</p>'
			. '<p class="mg-lm-cena">' . ( $g( 'std' ) ? '<s>' . esc_html( $cena( $g( 'std' ) ) ) . '</s> ' : '' ) . '<strong>' . esc_html( $cena( $g( 'lm' ) ) ) . '</strong><span> za cały termin</span></p>'
			. '<p class="mg-lm-przyciski"><a class="mg-lm-tel" href="' . esc_attr( MARIGO_TEL_HREF ) . '">Zadzwoń</a><a class="mg-lm-mail" href="mailto:biuro@marigo.pl?subject=' . $temat . '">Zapytaj mailowo</a></p>'
			. '</article>';
	}
	return $karty ? '<div class="mg-lm">' . $karty . '</div>' : '<p class="mg-lm-brak">Aktualnie brak ofert last minute. Zapytaj o wolne terminy: <a href="' . esc_attr( MARIGO_TEL_HREF ) . '">' . MARIGO_TEL . '</a>.</p>';
}

add_filter( 'the_content', function ( $html ) {
	if ( ! is_singular() || ( false === strpos( $html, 'mg-cennik-zrodlo' ) && false === strpos( $html, 'mg-lastminute' ) && false === strpos( $html, 'mg-cennik-wlasny' ) ) ) { return $html; }
	$dom = marigo_dom( $html );
	$xp = new DOMXPath( $dom );
	$wstaw = array();
	foreach ( iterator_to_array( $xp->query( '//*[contains(concat(" ", normalize-space(@class), " "), " mg-cennik-zrodlo ")]' ) ) as $g ) {
		$token = 'MGXCENNIK' . count( $wstaw ) . 'X';
		$wstaw[ $token ] = count( $wstaw ) ? '' : marigo_cennik_przelacznik_html();
		$g->parentNode->replaceChild( $dom->createTextNode( $token ), $g );
	}
	// jacht spoza /cennik/ (np. Futura 860): wlasna tabela Termin | Doba (| 7 dob) w grupie "mg-cennik-wlasny" - ten sam widok cennika
	foreach ( iterator_to_array( $xp->query( '//*[contains(concat(" ", normalize-space(@class), " "), " mg-cennik-wlasny ")]' ) ) as $g ) {
		$tab = $g->getElementsByTagName( 'table' )->item( 0 );
		if ( ! $tab ) { continue; }
		$t = array();
		foreach ( $tab->getElementsByTagName( 'tr' ) as $tr ) {
			$kom = array();
			foreach ( $tr->childNodes as $c ) {
				if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'td', 'th' ), true ) ) {
					$kom[] = trim( preg_replace( '/\s+/u', ' ', str_replace( "\xc2\xa0", ' ', $c->textContent ) ) );
				}
			}
			if ( $kom ) { $t[] = $kom; }
		}
		if ( count( $t ) < 2 ) { continue; }
		$tydz = false !== strpos( implode( ' ', $t[0] ), '7' );
		$t[0][0] = '';
		$token = 'MGXCW' . count( $wstaw ) . 'X';
		$wstaw[ $token ] = marigo_cennik_tabela_html( $t, 1, $tydz, true );
		$g->parentNode->replaceChild( $dom->createTextNode( $token ), $g );
	}
	foreach ( iterator_to_array( $xp->query( '//*[contains(concat(" ", normalize-space(@class), " "), " mg-lastminute ")]' ) ) as $g ) {
		$tab = $g->getElementsByTagName( 'table' )->item( 0 );
		if ( ! $tab ) { continue; }
		$karty = marigo_lastminute_html( $tab, $xp );
		if ( '' === $karty ) { continue; }
		$token = 'MGXLM' . count( $wstaw ) . 'X';
		$wstaw[ $token ] = $karty;
		$g->parentNode->replaceChild( $dom->createTextNode( $token ), $g );
	}
	return strtr( marigo_dom_html( $dom ), $wstaw );
}, 19 );

add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['marigo_cp'] ) ) { return; }
	echo "<script>(function(){var r=document.querySelector('.mg-cp');if(!r)return;r.classList.add('mg-cp-js');var b=r.querySelectorAll('.mg-cp-pig'),p=r.querySelectorAll('.mg-cp-panel');function pokaz(id){b.forEach(function(x){var a=x.getAttribute('data-cel')===id;x.classList.toggle('mg-cp-akt',a);x.setAttribute('aria-pressed',a?'true':'false')});p.forEach(function(x){x.hidden=x.id!==id})}b.forEach(function(x){x.addEventListener('click',function(){pokaz(x.getAttribute('data-cel'))})});var h=location.hash.replace('#','');pokaz(h&&document.getElementById(h)?h:b[0].getAttribute('data-cel'))})();</script>";
}, 60 );

/* ---------- 13. wpisy bloga: udostepnianie i komentarze ---------- */
/* Zamiast obrazkowych przyciskow wtyczki Ultimate Social Media Icons (ukrywane w style.css) - jedna linia "Udostepnij".
   Nowe komentarze we wpisach sa wylaczone (istniejace komentarze nadal sie wyswietlaja). */
add_filter( 'the_content', function ( $html ) {
	if ( ! is_singular( 'post' ) || ! in_the_loop() ) { return $html; }
	$url = get_permalink();
	return $html . '<p class="mg-udostepnij">Udostępnij: <a href="https://www.facebook.com/sharer/sharer.php?u=' . rawurlencode( $url ) . '" target="_blank" rel="noopener">Facebook</a>'
		. '<span aria-hidden="true">|</span><button type="button" class="mg-kopiuj" data-url="' . esc_attr( $url ) . '">Skopiuj link</button></p>'
		. "<script>(function(){var u=location.href.split('#')[0];document.querySelectorAll('.mg-udostepnij a[href*=\"sharer.php\"]').forEach(function(a){a.href='https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent(u)});document.querySelectorAll('.mg-kopiuj').forEach(function(b){b.setAttribute('data-url',u)})})();document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('.mg-kopiuj');if(!b)return;var u=location.href.split('#')[0];(navigator.clipboard?navigator.clipboard.writeText(u):Promise.reject()).then(function(){b.textContent='Link skopiowany'},function(){window.prompt('Skopiuj link:',u)})});</script>";
}, 30 );
add_filter( 'comments_open', function ( $otwarte, $id ) { return 'post' === get_post_type( $id ) ? false : $otwarte; }, 10, 2 );
add_filter( 'pings_open', function ( $otwarte, $id ) { return 'post' === get_post_type( $id ) ? false : $otwarte; }, 10, 2 );

/* ---------- 14. typografia tytulow (zwykly myslnik zamiast "–" i "—") ---------- */
// wptexturize zamienia " - " na "&#8211;" - dlatego filtry z wysokim priorytetem i takze dla encji
function marigo_bez_dlugich( $t ) { return str_replace( array( '–', '—', '&#8211;', '&#8212;', '&ndash;', '&mdash;' ), '-', (string) $t ); }
add_filter( 'the_title', function ( $t ) { return is_admin() ? $t : marigo_bez_dlugich( $t ); }, 99 );
add_filter( 'document_title', 'marigo_bez_dlugich', 99 );
add_filter( 'wp_title', 'marigo_bez_dlugich', 99 );
add_filter( 'rank_math/opengraph/facebook/og_title', 'marigo_bez_dlugich', 99 );
add_filter( 'rank_math/frontend/description', 'marigo_bez_dlugich', 99 );
add_filter( 'nav_menu_item_title', 'marigo_bez_dlugich', 99 );
add_filter( 'document_title_parts', function ( $p ) { foreach ( $p as $k => $v ) { $p[ $k ] = str_replace( array( '–', '—' ), '-', $v ); } return $p; } );
add_filter( 'rank_math/frontend/title', 'marigo_bez_dlugich', 99 );
add_filter( 'document_title_separator', function () { return '-'; } );

/* ---------- 15. lista wpisow: polski napis linku "czytaj dalej" (niezaleznie od tlumaczenia motywu) ---------- */
add_filter( 'generate_excerpt_more_text', function () { return 'Czytaj dalej'; } );
add_filter( 'generate_content_more_link_text', function () { return 'Czytaj dalej'; } );
add_filter( 'the_excerpt', 'marigo_bez_dlugich', 99 );

/* ---------- 16. blog i wpisy (v5) ---------- */
/* a) zajawki i opis meta bez spisu tresci wtyczki Easy Table of Contents ("Spis tresci Toggle ...") */
add_filter( 'the_content', function ( $html ) {
	if ( ! doing_filter( 'get_the_excerpt' ) && ! doing_filter( 'wp_trim_excerpt' ) ) { return $html; }
	return preg_replace( '#<div[^>]*id="ez-toc-container".*?</nav>\s*</div>#s', '', $html );
}, 999 );
function marigo_bez_spisu( $t ) {
	$t = preg_replace( '/^\s*Spis treści\s*(Toggle)?\s*/u', '', (string) $t );
	return preg_replace( '/\s*Spis treści\s+Toggle\s*/u', ' ', $t );
}
add_filter( 'get_the_excerpt', 'marigo_bez_spisu', 25 );
add_filter( 'rank_math/frontend/description', 'marigo_bez_spisu', 99 );
add_filter( 'rank_math/opengraph/facebook/og_description', 'marigo_bez_spisu', 99 );

/* b) data bez przecinka: "26 kwietnia 2022" (zamiast formatu "j F, Y" z ustawien) */
add_filter( 'option_date_format', function ( $f ) { return is_admin() ? $f : 'j F Y'; } );

/* c) lista wpisow: wpis bez obrazka wyroznionego dostaje pierwsze zdjecie z tresci albo estetyczny zastepnik */
function marigo_pierwsze_zdjecie( $id ) {
	$tresc = (string) get_post_field( 'post_content', $id );
	if ( preg_match( '/wp-image-(\d+)/', $tresc, $m ) ) {
		$img = wp_get_attachment_image( (int) $m[1], 'medium_large', false, array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ) );
		if ( $img ) { return $img; }
	}
	if ( preg_match( '/<img[^>]+src="([^"]+\/wp-content\/uploads\/[^"]+)"/i', $tresc, $m ) && false === stripos( $m[1], 'Hej-A-moze' ) ) {
		return '<img src="' . esc_url( $m[1] ) . '" alt="" loading="lazy" decoding="async">';
	}
	return '';
}
add_action( 'generate_after_entry_header', function () {
	if ( is_singular() || 'post' !== get_post_type() || has_post_thumbnail() ) { return; }
	$img = marigo_pierwsze_zdjecie( get_the_ID() );
	if ( '' === $img ) {
		$kat = get_the_category();
		$img = '<span class="mg-zast"><span class="mg-zast-k">' . esc_html( $kat ? $kat[0]->name : 'Blog' ) . '</span><span class="mg-zast-m">Marigo Czarter</span></span>';
	}
	echo '<div class="post-image mg-post-image-auto"><a href="' . esc_url( get_permalink() ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a></div>';
}, 9 );

/* d) baner klientki "Hej! A moze szukasz fajnej lodki..." (obrazek z linkiem do /kontakt/) jako ramka z przyciskami */
add_filter( 'the_content', function ( $html ) {
	if ( ! is_singular() || false === stripos( $html, '/kontakt' ) || false === stripos( $html, '<img' ) ) { return $html; }
	$dom = marigo_dom( $html );
	$xp = new DOMXPath( $dom );
	$zm = false;
	foreach ( iterator_to_array( $xp->query( '//figure[a[contains(@href,"/kontakt")]/img]' ) ) as $f ) {
		if ( trim( $f->textContent ) !== '' || $f->getElementsByTagName( 'img' )->length !== 1 ) { continue; }
		$box = $dom->createElement( 'div' );
		$box->setAttribute( 'class', 'mg-cta-ramka' );
		$f->parentNode->replaceChild( $box, $f );
		$box->appendChild( $f );
		$p = $dom->createElement( 'p' );
		$p->setAttribute( 'class', 'mg-cta-przyciski' );
		$a1 = $dom->createElement( 'a', 'Zadzwoń ' . MARIGO_TEL );
		$a1->setAttribute( 'href', MARIGO_TEL_HREF );
		$a1->setAttribute( 'class', 'mg-cta-tel' );
		$a2 = $dom->createElement( 'a', 'Napisz' );
		$a2->setAttribute( 'href', 'mailto:biuro@marigo.pl' );
		$a2->setAttribute( 'class', 'mg-cta-mail' );
		$p->appendChild( $a1 );
		$p->appendChild( $a2 );
		$box->appendChild( $p );
		$zm = true;
	}
	return $zm ? marigo_dom_html( $dom ) : $html;
}, 22 );

/* e) tabele we wpisach: krotkie tabele 2-kolumnowe (godziny, ceny) zostaja tabela na telefonie,
   pierwszy wiersz bez liczb = naglowek, puste wiersze i zbedne <br> na brzegach komorek usuwane */
add_action( 'wp_footer', function () {
	if ( ! is_singular() ) { return; }
	echo <<<'JS'
<script>(function(){document.querySelectorAll('.entry-content .wp-block-table table').forEach(function(t){var ec=t.closest('.entry-content'),a=t.parentElement.closest('[class*="mg-"]');if(a&&ec&&ec!==a&&ec.contains(a))return;[].forEach.call(t.querySelectorAll('td,th'),function(c){var e;while((e=c.firstElementChild||null)&&e.tagName==='BR'&&!c.firstChild.textContent.trim())e.remove();[].forEach.call(c.querySelectorAll('strong,b,span'),function(s){while(s.firstChild&&s.firstChild.nodeName==='BR')s.firstChild.remove();while(s.lastChild&&s.lastChild.nodeName==='BR')s.lastChild.remove()});while(c.lastChild&&c.lastChild.nodeName==='BR')c.lastChild.remove()});var w=[].filter.call(t.rows,function(r){return r.textContent.trim()||r.querySelector('img')});if(w.length<2)return;if(!w.every(function(r){return r.cells.length===2}))return;var dl=Math.max.apply(null,w.slice(1).map(function(r){return Math.max(r.cells[0].textContent.trim().length,r.cells[1].textContent.trim().length)}));if(dl>40)return;t.classList.add('mgx-2k');var cyf=function(r){return /\d/.test(r.textContent)};if(!cyf(w[0])&&w.slice(1).filter(cyf).length>=(w.length-1)/2)w[0].classList.add('mgx-n2');[].forEach.call(t.querySelectorAll('td'),function(c){if(/^[\d\s.:,*()+\-–]+$/.test(c.textContent.trim()))c.classList.add('mgx-nr')})})})();</script>
JS;
}, 61 );

/* ---------- 17. poprawki po tescie QA (v6) ---------- */
/* a) polskie napisy motywu i WordPressa (gdy brak tlumaczenia albo jest niepelne) */
add_filter( 'gettext', function ( $t, $o, $d ) {
	if ( is_admin() || ! in_array( $d, array( 'generatepress', 'gp-premium', 'default', 'contact-form-7' ), true ) ) { return $t; }
	static $pl = array(
		'Skip to content'    => 'Przejdź do treści',
		'Previous'           => 'Poprzednia',
		'Next'               => 'Następna',
		'Categories'         => 'Kategorie',
		'Tags'               => 'Tagi',
		'Page'               => 'Strona',
		'Read more about %s' => 'Czytaj dalej: %s',
		'More on %s'         => 'Czytaj dalej: %s',
		'Entry meta'         => 'Informacje o wpisie',
		'Mobile Toggle'      => 'Przełącznik menu',
		'Primary'            => 'Menu główne',
		'Site'               => 'Strona',
		'Archive Page'       => 'Strona archiwum',
		'Contact form'       => 'Formularz kontaktowy',
		'Post navigation'    => 'Nawigacja wpisu',
		'Posts navigation'   => 'Nawigacja wpisów',
	);
	return ( isset( $pl[ $o ] ) && $t === $o ) ? $pl[ $o ] : $t;
}, 20, 3 );
add_filter( 'gettext_with_context', function ( $t, $o, $c, $d ) {
	if ( is_admin() ) { return $t; }
	$pl = array( 'Previous' => 'Poprzednia', 'Next' => 'Następna', 'Page' => 'Strona', 'Primary' => 'Menu główne', 'Site' => 'Strona', 'Categories' => 'Kategorie', 'Tags' => 'Tagi' );
	return ( isset( $pl[ $o ] ) && $t === $o ) ? $pl[ $o ] : $t;
}, 20, 4 );

/* b) tresc stron i wpisow: zepsute linki ze starych tresci, resztki wtyczki Ultimate Social Media Icons, drugi H1 */
add_filter( 'the_content', function ( $html ) {
	if ( ! is_singular() || '' === trim( (string) $html ) ) { return $html; }
	$dom = marigo_dom( $html );
	$xp = new DOMXPath( $dom );
	$zm = false;
	// resztki wtyczki udostepniania wklejone w tresc (ikony ladowane z marigo.pl, skrypty Twittera itp.)
	foreach ( iterator_to_array( $xp->query( '//*[contains(@class,"sfsi")][not(ancestor::*[contains(@class,"sfsi")])]' ) ) as $e ) {
		$e->parentNode->removeChild( $e );
		$zm = true;
	}
	// drugi H1 w tresci starych stron (tytul strony jest juz H1) -> H2 z tymi samymi klasami; H1 w nowych blokach (mg-...) zostaje
	foreach ( is_front_page() ? array() : iterator_to_array( $xp->query( '//h1[not(ancestor::*[contains(@class,"mg-")])]' ) ) as $h ) {
		$h2 = $dom->createElement( 'h2' );
		foreach ( iterator_to_array( $h->attributes ) as $at ) { $h2->setAttribute( $at->name, $at->value ); }
		while ( $h->firstChild ) { $h2->appendChild( $h->firstChild ); }
		$h->parentNode->replaceChild( $h2, $h );
		$zm = true;
	}
	// zepsute linki: numer telefonu jako adres, e-mail doklejony do adresu strony, akapit tekstu zamiast adresu, kotwica bez celu
	$idy = array();
	foreach ( $xp->query( '//*[@id or @name]' ) as $e ) {
		$idy[ $e->getAttribute( 'id' ) ] = true;
		$idy[ $e->getAttribute( 'name' ) ] = true;
	}
	foreach ( iterator_to_array( $dom->getElementsByTagName( 'a' ) ) as $a ) {
		$h = trim( (string) $a->getAttribute( 'href' ) );
		if ( '' === $h ) { continue; }
		$hd = rawurldecode( $h );
		if ( preg_match( '#^https?://\+?([\d\s()-]{9,})/?$#', $hd, $m ) ) {
			$a->setAttribute( 'href', 'tel:+48' . substr( preg_replace( '/\D/', '', $m[1] ), -9 ) );
			$zm = true;
			continue;
		}
		if ( preg_match( '#^https?://[^@\s]+/([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,})/?$#', $hd, $m ) ) {
			$a->setAttribute( 'href', 'mailto:' . $m[1] );
			$zm = true;
			continue;
		}
		// adres, w ktorym juz nazwa domeny zawiera spacje (wklejony akapit tekstu zamiast adresu)
		$bez_linku = (bool) preg_match( '#^(https?:)?//[^/?\#]*\s#', $hd );
		if ( ! $bez_linku && is_singular( 'post' ) && '#' === $h[0] && strlen( $h ) > 1 && empty( $idy[ substr( $hd, 1 ) ] ) ) { $bez_linku = true; }
		if ( $bez_linku ) {
			while ( $a->firstChild ) { $a->parentNode->insertBefore( $a->firstChild, $a ); }
			$a->parentNode->removeChild( $a );
			$zm = true;
		}
	}
	return $zm ? marigo_dom_html( $dom ) : $html;
}, 23 );

/* c) formularze CF7: krotka informacja RODO pod przyciskiem (bez dodatkowej zgody) */
add_filter( 'wpcf7_form_elements', function ( $html ) {
	return $html . '<p class="mg-rodo">Dane z formularza wykorzystamy tylko do odpowiedzi na Twoje zapytanie. Administratorem danych jest PHU Marigo Mariusz Siennicki. Szczegóły: <a href="' . esc_url( home_url( '/polityka-prywatnosci/' ) ) . '">polityka prywatności</a>.</p>';
} );

/* d) canonical na liscie bloga i w kategoriach (WordPress dodaje go sam tylko na stronach i wpisach; Rank Math robi to sam) */
add_action( 'wp_head', function () {
	if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) || ! ( is_home() || is_category() || is_tag() ) ) { return; }
	$url = is_home() ? get_permalink( (int) get_option( 'page_for_posts' ) ) : get_term_link( get_queried_object() );
	if ( is_wp_error( $url ) || ! $url ) { return; }
	$n = (int) get_query_var( 'paged' );
	if ( $n > 1 ) { $url = trailingslashit( $url ) . 'page/' . $n . '/'; }
	echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
}, 5 );

/* e) powiekszanie zdjec (galerie jachtow, galerie i zdjecia we wpisach): lekki lightbox ze strzalkami, przesuwaniem palcem, Esc
   i zamykaniem klikiem w tlo. Przejmuje klikniecie przed WP Featherlight / FancyBox, wiec dziala tak samo z nimi i bez nich. */
add_action( 'wp_footer', function () {
	if ( ! is_singular() ) { return; }
	echo <<<'MGLB'
<script>(function(){
var R=/\.(jpe?g|png|webp|gif|avif)(\?.*)?$/i,box,img,cap,lista=[],i=0,x0=null;
function linki(){return [].filter.call(document.querySelectorAll('.entry-content a[href], .mg-jhero a[href]'),function(a){return R.test(a.getAttribute('href'))&&a.querySelector('img');});}
function pokaz(k){i=(k+lista.length)%lista.length;var a=lista[i],im=a.querySelector('img');img.src=a.href;img.alt=im?im.alt:'';cap.textContent=lista.length>1?(i+1)+' / '+lista.length:'';box.querySelectorAll('.mg-lb-n').forEach(function(b){b.hidden=lista.length<2;});}
function zamknij(){box.hidden=true;document.documentElement.classList.remove('mg-lb-on');img.removeAttribute('src');if(box._a)box._a.focus();}
function zbuduj(){box=document.createElement('div');box.className='mg-lb';box.hidden=true;box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-label','Powiększone zdjęcie');
box.innerHTML='<img class="mg-lb-img" alt=""><p class="mg-lb-cap"></p><button type="button" class="mg-lb-x" aria-label="Zamknij">×</button><button type="button" class="mg-lb-n mg-lb-p" aria-label="Poprzednie zdjęcie">‹</button><button type="button" class="mg-lb-n mg-lb-d" aria-label="Następne zdjęcie">›</button>';
document.body.appendChild(box);img=box.querySelector('.mg-lb-img');cap=box.querySelector('.mg-lb-cap');
box.addEventListener('click',function(e){if(e.target.closest('.mg-lb-p'))pokaz(i-1);else if(e.target.closest('.mg-lb-d'))pokaz(i+1);else if(e.target===box||e.target.closest('.mg-lb-x'))zamknij();});
box.addEventListener('touchstart',function(e){x0=e.touches[0].clientX;},{passive:true});
box.addEventListener('touchend',function(e){if(x0===null)return;var dx=e.changedTouches[0].clientX-x0;x0=null;if(Math.abs(dx)>40&&lista.length>1)pokaz(dx<0?i+1:i-1);});
document.addEventListener('keydown',function(e){if(box.hidden)return;if(e.key==='Escape')zamknij();else if(e.key==='ArrowRight')pokaz(i+1);else if(e.key==='ArrowLeft')pokaz(i-1);});}
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a||e.ctrlKey||e.metaKey||e.shiftKey||e.button)return;lista=linki();var k=lista.indexOf(a);if(k<0)return;e.preventDefault();e.stopImmediatePropagation();if(!box)zbuduj();box._a=a;box.hidden=false;document.documentElement.classList.add('mg-lb-on');pokaz(k);box.querySelector('.mg-lb-x').focus();},true);
})();</script>
MGLB;

}, 62 );
/* f) "Read more about ..." w linku "Czytaj dalej" (motyw sklada ten napis bez tlumaczenia) */
function marigo_czytaj_dalej_pl( $t ) { return str_replace( array( 'aria-label="Read more about ', '>Read more<' ), array( 'aria-label="Czytaj dalej: ', '>Czytaj dalej<' ), (string) $t ); }
add_filter( 'get_the_excerpt', 'marigo_czytaj_dalej_pl', 30 );
add_filter( 'the_excerpt', 'marigo_czytaj_dalej_pl', 30 );
add_filter( 'the_content_more_link', 'marigo_czytaj_dalej_pl', 30 );
add_filter( 'generate_excerpt_more_output', 'marigo_czytaj_dalej_pl', 30 );
add_filter( 'generate_content_more_link_output', 'marigo_czytaj_dalej_pl', 30 );
/* g) kategorie bloga bez opisu meta (na produkcji Rank Math ich nie ma): krotki opis z nazwy kategorii */
function marigo_opis_kategorii() {
	if ( ! is_category() ) { return ''; }
	return 'Wpisy z kategorii ' . single_cat_title( '', false ) . ' na blogu Marigo Czarter: porady, porty, szlaki i aktualności z Wielkich Jezior Mazurskich.';
}
add_filter( 'rank_math/frontend/description', function ( $d ) { return ( '' === trim( (string) $d ) && is_category() ) ? marigo_opis_kategorii() : $d; }, 20 );
add_action( 'wp_head', function () {
	if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) || ! is_category() ) { return; }
	echo '<meta name="description" content="' . esc_attr( marigo_opis_kategorii() ) . '">' . "\n";
}, 2 );

/* ---------- 18. wyszukiwarka "termin + budzet" (v7): [marigo_szukaj] na /cennik/, [marigo_szukaj tryb="skrot"] na stronie glownej ----------
   Dane: te same tabele /cennik/ (okresy i ceny jachtow) + karty jachtow ze strony glownej (zdjecie, typ, osoby, bez patentu).
   PHP wstawia dane jako JSON, liczenie ceny dzien po dniu robi skrypt w przegladarce (bez bibliotek). */
function marigo_szukaj_dane() {
	$jachty = marigo_jachty_z_kart();
	$info = array();
	foreach ( marigo_karty() as $k ) {
		$img = '';
		if ( preg_match( '/<img[^>]+src="([^"]+)"/', $k['html'], $m ) ) { $img = $m[1]; }
		$os = 0;
		$tekst = html_entity_decode( wp_strip_all_tags( $k['html'] ), ENT_QUOTES, 'UTF-8' );
		if ( preg_match( '/(\d+)\s*(?:\+\s*(\d+))?\s*os/u', $tekst, $m ) ) { $os = (int) $m[1] + ( isset( $m[2] ) ? (int) $m[2] : 0 ); }
		$info[ $k['sciezka'] ] = array( 'img' => $img, 'os' => $os, 'bez' => ! empty( $k['bez'] ) );
	}
	$rok = marigo_rok_sezonu();
	$start = 999;
	$koniec = 0;
	$lista = array();
	$uzyte = array();
	foreach ( marigo_tabele_cennika() as $t ) {
		foreach ( $t[0] as $i => $nagl ) {
			if ( 0 === $i || '' === trim( $nagl ) ) { continue; }
			list( $okresy, $dod ) = marigo_cennik_okresy( $t, $i );
			$o = array();
			foreach ( $okresy as $ok ) {
				if ( ! $ok[3] ) { continue; }
				$o[] = array( $ok[0], $ok[1], $ok[3] );
				$start = min( $start, $ok[0] );
				$koniec = max( $koniec, $ok[1] );
			}
			$kaucja = 0;
			$sprz = 0;
			foreach ( $dod as $d ) {
				$v = (int) preg_replace( '/[^0-9]/', '', $d[1] );
				if ( false !== stripos( $d[0], 'kaucj' ) ) { $kaucja = $v; } elseif ( false !== stripos( $d[0], 'sprz' ) ) { $sprz = $v; }
			}
			foreach ( marigo_jachty_kolumny( $nagl, $jachty ) as $nazwa => $dane ) {
				$inf = isset( $info[ $dane[0] ] ) ? $info[ $dane[0] ] : array( 'img' => '', 'os' => 0, 'bez' => false );
				$lista[] = array( 'n' => $nazwa, 'k' => trim( $nagl ), 'url' => home_url( '/' . $dane[0] . '/' ), 'typ' => $dane[1], 'img' => $inf['img'], 'os' => $inf['os'], 'bez' => $inf['bez'], 'o' => $o, 'kaucja' => $kaucja, 'sprz' => $sprz );
				$uzyte[ $nazwa ] = true;
			}
		}
	}
	// jachty z kart bez kolumny w cenniku: cena na zapytanie
	foreach ( $jachty as $nazwa => $dane ) {
		if ( isset( $uzyte[ $nazwa ] ) ) { continue; }
		$inf = isset( $info[ $dane[0] ] ) ? $info[ $dane[0] ] : array( 'img' => '', 'os' => 0, 'bez' => false );
		$lista[] = array( 'n' => $nazwa, 'k' => $nazwa, 'url' => home_url( '/' . $dane[0] . '/' ), 'typ' => $dane[1], 'img' => $inf['img'], 'os' => $inf['os'], 'bez' => $inf['bez'], 'o' => array(), 'kaucja' => 0, 'sprz' => 0 );
	}
	return array( 'rok' => $rok, 'start' => 999 === $start ? 0 : $start, 'koniec' => $koniec, 'jachty' => $lista, 'tel' => MARIGO_TEL, 'tel_href' => MARIGO_TEL_HREF, 'cennik' => home_url( '/cennik/' ) );
}

add_shortcode( 'marigo_szukaj', function ( $atts ) {
	$a = shortcode_atts( array( 'tryb' => 'pelny' ), $atts );
	$skrot = 'skrot' === $a['tryb'];
	$dane = marigo_szukaj_dane();
	if ( ! $dane['jachty'] ) { return ''; }
	$doby = '';
	foreach ( array( 2, 3, 4, 5, 6, 7, 8, 10, 14 ) as $n ) { $doby .= '<option value="' . $n . '"' . ( 7 === $n ? ' selected' : '' ) . '>' . $n . ( $n < 5 ? ' doby' : ' dób' ) . ( 7 === $n ? ' (tydzień)' : '' ) . '</option>'; }
	$h = '<div class="mg-sz' . ( $skrot ? ' mg-sz-skrot' : '' ) . '"' . ( $skrot ? '' : ' id="szukaj"' ) . '>';
	$h .= '<form class="mg-sz-form" action="' . esc_url( home_url( '/cennik/' ) ) . '#szukaj" method="get">'
		. '<label class="mg-sz-p mg-sz-od"><span>Przyjazd</span><input type="date" name="od" required></label>'
		. '<label class="mg-sz-p"><span>Ile dób</span><select name="doby">' . $doby . '</select></label>'
		. '<label class="mg-sz-p"><span>Budżet od (zł)</span><input type="number" name="min" min="0" step="100" inputmode="numeric" value="0"></label>'
		. '<label class="mg-sz-p"><span>Budżet do (zł)</span><input type="number" name="max" min="0" step="100" inputmode="numeric" value="' . ( $skrot ? 6000 : 6000 ) . '"></label>';
	if ( ! $skrot ) {
		$h .= '<label class="mg-sz-p"><span>Rodzaj</span><select name="typ"><option value="">wszystkie</option><option value="zaglowe">żaglowe</option><option value="motorowe">motorowe</option></select></label>'
			. '<label class="mg-sz-p"><span>Osób</span><select name="osob"><option value="">dowolnie</option><option value="2">2+</option><option value="4">4+</option><option value="6">6+</option><option value="8">8+</option><option value="9">9+</option></select></label>';
	} else {
		$h .= '<button type="submit" class="mg-sz-pokaz">Pokaż jachty</button>';
	}
	$h .= '</form><div class="mg-sz-wyniki" aria-live="polite"><noscript><p class="mg-sz-info">Wyszukiwarka wymaga JavaScript - ceny wszystkich jachtów są w cenniku poniżej.</p></noscript></div></div>';
	$GLOBALS['marigo_sz'] = $dane;
	return $h;
} );
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['marigo_sz'] ) ) { return; }
	echo '<script type="application/json" id="mg-sz-dane">' . wp_json_encode( $GLOBALS['marigo_sz'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	echo <<<'MGSZ'
<script>(function(){
var D=JSON.parse(document.getElementById('mg-sz-dane').textContent),MS=86400000;
var MIES=['stycznia','lutego','marca','kwietnia','maja','czerwca','lipca','sierpnia','września','października','listopada','grudnia'];
function zl(n){return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g,' ')+' zł';}
function dzien(d){return Math.round((Date.UTC(d.getUTCFullYear(),d.getUTCMonth(),d.getUTCDate())-Date.UTC(D.rok,0,1))/MS);}
function slownie(n){var d=new Date(Date.UTC(D.rok,0,1)+n*MS);return d.getUTCDate()+' '+MIES[d.getUTCMonth()];}
function iso(d){return d.toISOString().slice(0,10);}
function domyslna(){var t=new Date(),d=new Date(Date.UTC(t.getFullYear(),t.getMonth(),t.getDate()+14));var n=dzien(d);if(d.getUTCFullYear()!==D.rok||n<D.start||n+7>D.koniec)d=new Date(Date.UTC(D.rok,6,1));while(d.getUTCDay()!==6)d=new Date(d.getTime()+MS);return iso(d);}
function cena(j,od,doby){var s=0;for(var k=0;k<doby;k++){var n=od+k,c=0;for(var q=0;q<j.o.length;q++){if(j.o[q][0]<=n&&n<j.o[q][1]){c=j.o[q][2];break;}}if(!c)return null;s+=c;}return s;}
function esc(t){var e=document.createElement('i');e.textContent=t;return e.innerHTML;}
function karta(j,suma,doby,twoj){var h='<article class="mg-sz-k'+(twoj?' mg-sz-twoj':'')+'">'+(j.img?'<img src="'+j.img+'" alt="" loading="lazy" decoding="async">':'<span class="mg-sz-bezimg"></span>')+'<div class="mg-sz-kt">';
h+='<p class="mg-sz-n">'+(twoj?'<small>Twój jacht</small>':'')+'<a href="'+j.url+'">'+esc(j.n)+'</a></p><p class="mg-sz-m">'+(j.typ==='zaglowe'?'jacht żaglowy':'jacht motorowy')+(j.os?' · do '+j.os+' osób':'')+' · '+(j.bez?'bez patentu':'z patentem')+'</p>';
if(suma!==null){h+='<p class="mg-sz-cena"><b>'+zl(suma)+'</b> za '+doby+(doby===1?' dobę':(doby<5?' doby':' dób'))+'<span>'+zl(suma/doby)+' / doba średnio</span></p>';var dd=[];if(j.kaucja)dd.push('kaucja '+zl(j.kaucja));if(j.sprz)dd.push('sprzątanie '+zl(j.sprz));if(dd.length)h+='<p class="mg-sz-dod">+ '+dd.join(' · ')+' (płatne osobno)</p>';}
else h+='<p class="mg-sz-cena"><b>cena na zapytanie</b></p>';
h+='<p class="mg-sz-btn"><a class="mg-sz-b1" href="'+j.url+'#kalendarz">Sprawdź wolny termin</a><a class="mg-sz-b2" href="'+D.tel_href+'">Zapytaj</a></p></div></article>';return h;}
document.querySelectorAll('.mg-sz').forEach(function(box){
var f=box.querySelector('form'),wy=box.querySelector('.mg-sz-wyniki'),skrot=box.classList.contains('mg-sz-skrot');
var p=new URLSearchParams(location.search),jacht=p.get('jacht')||'';
var pola={od:f.elements.od,doby:f.elements.doby,min:f.elements.min,max:f.elements.max,typ:f.elements.typ,osob:f.elements.osob};
pola.od.value=/^\d{4}-\d\d-\d\d$/.test(p.get('od')||'')?p.get('od'):domyslna();
['doby','min','max','typ','osob'].forEach(function(k){if(pola[k]&&p.get(k)!==null&&p.get(k)!=='')pola[k].value=p.get(k);});
function licz(){
var od=new Date(pola.od.value+'T00:00:00Z'),doby=Math.max(1,Math.min(28,parseInt(pola.doby.value,10)||7)),mn=parseInt(pola.min.value,10)||0,mx=parseInt(pola.max.value,10)||0,typ=pola.typ?pola.typ.value:'',os=pola.osob?parseInt(pola.osob.value,10)||0:0;
if(isNaN(od.getTime())){wy.innerHTML='<p class="mg-sz-info">Wybierz datę przyjazdu.</p>';return;}
if(mx&&mx<mn){var x=mn;mn=mx;mx=x;}
var n=dzien(od),koniec=new Date(od.getTime()+doby*MS),opis=od.getUTCDate()+' '+MIES[od.getUTCMonth()]+' - '+koniec.getUTCDate()+' '+MIES[koniec.getUTCMonth()];
var lista=D.jachty.filter(function(j){return(!typ||j.typ===typ)&&(!os||!j.os||j.os>=os);});
var w=[],wyzej=[],brak=[],twoj=null;
lista.forEach(function(j){if(!j.o.length){brak.push(j);return;}var s=cena(j,n,doby);if(s===null)return;var r={j:j,s:s};if(jacht&&j.k===jacht){twoj=r;}if((!mx||s<=mx)&&s>=mn)w.push(r);else if(mx&&s>mx&&s<=mx*1.15)wyzej.push(r);});
w.sort(function(a,b){return a.s-b.s;});wyzej.sort(function(a,b){return a.s-b.s;});
var poza=od.getUTCFullYear()!==D.rok||n<D.start||n+doby>D.koniec;
var h='';
if(poza)h+='<p class="mg-sz-info mg-sz-uwaga">Ten termin wypada poza sezonem cennika ('+slownie(D.start)+' - '+slownie(D.koniec)+' '+D.rok+'). Cenę poza sezonem podamy telefonicznie: <a href="'+D.tel_href+'">'+D.tel+'</a>.</p>';
var ile=w.length;
if(!poza)h+='<p class="mg-sz-info"><b>'+opis+'</b> ('+doby+(doby===1?' doba':(doby<5?' doby':' dób'))+'): '+(ile?ile+(ile===1?' jacht':(ile<5?' jachty':' jachtów'))+' w Twoim budżecie, od najtańszego.':'brak jachtów w tym budżecie.')+'</p>';
if(twoj&&!skrot)h+=karta(twoj.j,twoj.s,doby,true);
if(skrot){w.slice(0,3).forEach(function(r){h+=karta(r.j,r.s,doby);});if(!w.length&&wyzej.length)wyzej.slice(0,3).forEach(function(r){h+=karta(r.j,r.s,doby);});
var q=new URLSearchParams();q.set('od',pola.od.value);q.set('doby',doby);if(mn)q.set('min',mn);if(mx)q.set('max',mx);
h+='<p class="mg-sz-wszystkie"><a href="'+D.cennik+'?'+q.toString()+'#szukaj">Zobacz wszystkie wyniki'+(w.length>3?' ('+w.length+')':'')+'</a></p>';}
else{w.forEach(function(r){if(!twoj||r!==twoj)h+=karta(r.j,r.s,doby);});
if(wyzej.length)h+='<details class="mg-sz-wyzej"><summary>Trochę powyżej budżetu (do +15%) - '+wyzej.length+'</summary>'+wyzej.map(function(r){return karta(r.j,r.s,doby);}).join('')+'</details>';
if(brak.length)h+='<p class="mg-sz-h">Cena na zapytanie</p>'+brak.map(function(j){return karta(j,null,doby);}).join('');}
h+='<p class="mg-sz-info mg-sz-mala">Ceny z cennika '+D.rok+', bez rabatów. Wolne terminy potwierdza kalendarz na stronie jachtu.</p>';
wy.innerHTML=h;}
f.addEventListener('input',licz);f.addEventListener('change',licz);f.addEventListener('submit',function(e){e.preventDefault();licz();if(skrot){var a=box.querySelector('.mg-sz-wszystkie a');if(a)location.href=a.href;}});
licz();
if(location.hash==='#szukaj'&&!skrot)setTimeout(function(){box.scrollIntoView();},50);
});
})();</script>
MGSZ;
}, 63 );

/* ---------- 18. v9 (29.10.2026): uklad z pierwszej koncepcji, oryginalne teksty ----------
   Strona glowna i strony jachtow w ukladzie z pierwszej wizualizacji (granat + czerwien z logo).
   Wszystkie teksty tresci to oryginalne teksty klientki; ponizsze funkcje tylko je ukladaja.
   a) klasa body "m9-strona" dla stron w nowym ukladzie (klasy blokow zaczynajace sie od "m9-"),
   b) [marigo_zasady sekcje="rabaty,doplaty"] - listy RABATY / DOPLATY / PROCEDURA REZERWACJI / WAZNE INFO
      wziete ze strony /cennik/ (edytuje sie je tylko tam, jak ceny),
   c) ikonki przy punktach list z klasa "m9-ikony" (dobierane po pierwszych slowach punktu, tekst bez zmian),
   d) zakladki (taby): grupa "m9-taby" z grupami "m9-tab" - kazda zaczyna sie naglowkiem, ktory jest nazwa zakladki;
      na telefonie te same sekcje rozwijane po dotknieciu naglowka; bez JavaScriptu wszystko widoczne,
   e) [marigo_podobne] jako karuzela (wszystkie jachty tego samego typu, przewijane w bok),
   f) [marigo_poradniki typ="motorowe|zaglowe"] - linki do wpisow z bloga (tytuly wpisow z WordPressa),
   g) [marigo_porty] - kafelki "Popularne porty startowe" skopiowane ze strony glownej (jedno miejsce edycji),
   h) strona glowna: filtr kart jachtow (Wszystkie / Zaglowe / Motorowe / Bez patentu). */

/* a) */
add_filter( 'body_class', function ( $classes ) {
	if ( marigo_tresc_zawiera( 'm9-' ) ) { $classes[] = 'm9-strona'; }
	return $classes;
}, 20 );

/* b) */
function marigo_zasady_listy() {
	static $wynik = null;
	if ( null !== $wynik ) { return $wynik; }
	$wynik = array();
	$strona = get_page_by_path( 'cennik' );
	if ( ! $strona || ! class_exists( 'DOMDocument' ) ) { return $wynik; }
	$klucz = 'mg_zasady_' . $strona->ID . '_' . md5( $strona->post_modified_gmt . MARIGO_WERSJA );
	$c = get_transient( $klucz );
	if ( is_array( $c ) ) { $wynik = $c; return $wynik; }
	$dom = marigo_dom( do_blocks( $strona->post_content ) );
	$xp = new DOMXPath( $dom );
	$szukane = array( 'rabaty' => 'RABATY', 'doplaty' => 'DOPŁATY', 'procedura' => 'PROCEDURA REZERWACJI', 'wazne' => 'WAŻNE INFO' );
	foreach ( $xp->query( '//p|//h2|//h3|//h4|//h5' ) as $el ) {
		$t = trim( preg_replace( '/\s+/u', ' ', str_replace( "\xc2\xa0", ' ', $el->textContent ) ), " :\t\n" );
		$t = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( $t, 'UTF-8' ) : strtoupper( $t );
		$k = array_search( $t, $szukane, true );
		if ( false === $k || isset( $wynik[ $k ] ) ) { continue; }
		$n = $el->nextSibling;
		while ( $n && ( ! ( $n instanceof DOMElement ) || ( 'p' === strtolower( $n->nodeName ) && '' === trim( $n->textContent ) ) ) ) { $n = $n->nextSibling; }
		if ( $n instanceof DOMElement && in_array( strtolower( $n->nodeName ), array( 'ul', 'ol' ), true ) ) {
			$n->removeAttribute( 'style' );
			$wynik[ $k ] = array( trim( $el->textContent ), $dom->saveHTML( $n ) );
		}
	}
	set_transient( $klucz, $wynik, WEEK_IN_SECONDS );
	return $wynik;
}
add_shortcode( 'marigo_zasady', function ( $atts ) {
	$a = shortcode_atts( array( 'sekcje' => 'rabaty,doplaty' ), $atts );
	$listy = marigo_zasady_listy();
	$h = '';
	foreach ( array_map( 'trim', explode( ',', (string) $a['sekcje'] ) ) as $k ) {
		if ( empty( $listy[ $k ] ) ) { continue; }
		$h .= '<div class="m9-zasada m9-zasada-' . esc_attr( $k ) . '"><p class="m9-etyk">' . esc_html( $listy[ $k ][0] ) . '</p>' . $listy[ $k ][1] . '</div>';
	}
	return $h ? '<div class="m9-zasady">' . $h . '</div>' : '';
} );

/* c) */
function marigo_ikona_punktu( $tekst ) {
	$t = function_exists( 'mb_strtolower' ) ? mb_strtolower( $tekst, 'UTF-8' ) : strtolower( $tekst );
	$mapa = array(
		'osoby'      => '/(liczba|ilość|ilosc|maksymalna liczba) (osób|załogi)|^załoga|osób|osoby/u',
		'wysokosc'   => '/wysokość|prześwit/u',
		'fekalia'    => '/fekali|szar/u',
		'paliwo'     => '/paliw|spalanie|bak\b/u',
		'kabiny'     => '/kabin|kajut/u',
		'koje'       => '/koj[ae]|koi\b|spani/u',
		'lazienka'   => '/łazien|wc\b|toalet/u',
		'ster'       => '/ster(y|ów)? strumieniow|strumieniow/u',
		'dlugosc'    => '/długość|dlugosc|szerokość/u',
		'zanurzenie' => '/zanurzenie|miecz/u',
		'silnik'     => '/silnik|km\b|napęd/u',
		'woda'       => '/wod[ay]|bojler|zbiornik/u',
		'masa'       => '/masa|ciężar|wyporność|ładowność/u',
		'zagiel'     => '/żag|grot|fok|genua|maszt/u',
		'rocznik'    => '/rocznik|rok produkcji|rok budowy/u',
		'uprawnienia'=> '/uprawnieni|patent/u',
		'wydanie'    => '/wydanie|odbiór/u',
		'zdanie'     => '/zdanie/u',
		'kaucja'     => '/kaucj/u',
		'sprzatanie' => '/sprzątani|dezynfekc/u',
		'port'       => '/port|keja/u',
	);
	foreach ( $mapa as $k => $re ) { if ( preg_match( $re, $t ) ) { return $k; } }
	return 'punkt';
}
add_filter( 'the_content', function ( $html ) {
	if ( false === strpos( $html, 'm9-ikony' ) ) { return $html; }
	return preg_replace_callback( '#(<ul[^>]*class="[^"]*m9-ikony[^"]*"[^>]*>)(.*?)(</ul>)#su', function ( $m ) {
		$li = preg_replace_callback( '#<li(\s[^>]*)?>(.*?)</li>#su', function ( $x ) {
			$at = isset( $x[1] ) ? $x[1] : '';
			$k = 'm9-i-' . marigo_ikona_punktu( wp_strip_all_tags( $x[2] ) );
			if ( preg_match( '/class="([^"]*)"/', $at ) ) { $at = preg_replace( '/class="([^"]*)"/', 'class="$1 ' . $k . '"', $at, 1 ); }
			else { $at .= ' class="' . $k . '"'; }
			return '<li' . $at . '>' . $x[2] . '</li>';
		}, $m[2] );
		return $m[1] . $li . $m[3];
	}, $html );
}, 25 );

/* d) */
add_action( 'wp_footer', function () {
	if ( ! marigo_tresc_zawiera( 'm9-taby' ) ) { return; }
	echo <<<'MGTABY'
<script>(function(){
var tel=window.matchMedia('(max-width:900px)');
document.querySelectorAll('.m9-taby').forEach(function(box,b){
var panele=[].filter.call(box.querySelectorAll('.m9-tab'),function(c){return c.parentNode===box||c.parentNode.parentNode===box;});
if(panele.length<2)return;
var nav=document.createElement('div');nav.className='m9-taby-nav';nav.setAttribute('role','tablist');
var przyc=[];
panele.forEach(function(p,i){
var h=p.querySelector('h2,h3,h4');var nazwa=h?h.textContent.trim():('Zakładka '+(i+1));
var id='m9t'+b+'-'+i;p.id=p.id||id;p.setAttribute('role','tabpanel');
var bt=document.createElement('button');bt.type='button';bt.className='m9-taby-b';bt.setAttribute('role','tab');bt.setAttribute('aria-controls',p.id);bt.textContent=nazwa;
bt.addEventListener('click',function(){pokaz(i,true);});
bt.addEventListener('keydown',function(e){var k=e.key==='ArrowDown'||e.key==='ArrowRight'?1:(e.key==='ArrowUp'||e.key==='ArrowLeft'?-1:0);if(!k)return;e.preventDefault();var n=(i+k+panele.length)%panele.length;pokaz(n,true);przyc[n].focus();});
nav.appendChild(bt);przyc.push(bt);
if(h){h.classList.add('m9-tab-h');h.setAttribute('tabindex','0');h.setAttribute('role','button');h.setAttribute('aria-expanded','false');
var tog=function(){var o=p.classList.toggle('m9-otw');h.setAttribute('aria-expanded',o?'true':'false');};
h.addEventListener('click',function(){if(tel.matches)tog();});
h.addEventListener('keydown',function(e){if(tel.matches&&(e.key==='Enter'||e.key===' ')){e.preventDefault();tog();}});}
});
function pokaz(n,fokus){panele.forEach(function(p,i){var a=i===n;p.classList.toggle('m9-akt',a);przyc[i].setAttribute('aria-selected',a?'true':'false');przyc[i].tabIndex=a?0:-1;});}
panele[0].parentNode.insertBefore(nav,panele[0]);box.classList.add('m9-taby-js');pokaz(0);
});
})();</script>
MGTABY;
}, 61 );

/* e) karuzela "Podobne jachty": wszystkie jachty tego samego typu (karty ze strony glownej), przewijane w bok */
remove_shortcode( 'marigo_podobne' );
add_shortcode( 'marigo_podobne', function ( $atts ) {
	$a = shortcode_atts( array( 'typ' => '', 'ile' => 12, 'bez' => '' ), $atts );
	$teraz = marigo_sciezka( get_permalink() );
	$bez = trim( (string) $a['bez'], '/' );
	$typ = sanitize_key( $a['typ'] );
	$karty = array_values( marigo_karty() );
	$poz = 0;
	foreach ( $karty as $i => $k ) { if ( $k['sciezka'] === $teraz ) { $poz = $i; if ( '' === $typ ) { $typ = $k['typ']; } } }
	$lista = array();
	foreach ( $karty as $i => $k ) {
		if ( $k['sciezka'] === $teraz || ( '' !== $bez && 0 === strpos( $k['sciezka'], $bez ) ) ) { continue; }
		if ( '' !== $typ && $typ !== $k['typ'] ) { continue; }
		$lista[] = array( abs( $i - $poz ), $i, $k['html'] );
	}
	usort( $lista, function ( $x, $y ) { return $x[0] === $y[0] ? $x[1] - $y[1] : $x[0] - $y[0]; } );
	$lista = array_slice( $lista, 0, max( 1, (int) $a['ile'] ) );
	if ( ! $lista ) { return ''; }
	$html = '';
	foreach ( $lista as $k ) { $html .= $k[2]; }
	$GLOBALS['marigo_karuzela'] = true;
	return '<div class="m9-karuzela"><div class="mg-flota mg-flota-podobne m9-tor" tabindex="0" aria-label="Podobne jachty - przewiń w bok">' . $html . '</div>'
		. '<div class="m9-kar-nav"><button type="button" class="m9-kar-b m9-kar-w" aria-label="Poprzednie jachty">‹</button><button type="button" class="m9-kar-b m9-kar-d" aria-label="Następne jachty">›</button></div></div>';
} );
add_action( 'wp_footer', function () {
	if ( empty( $GLOBALS['marigo_karuzela'] ) ) { return; }
	echo "<script>document.querySelectorAll('.m9-karuzela').forEach(function(k){var t=k.querySelector('.m9-tor');function s(d){var c=t.querySelector('.mg-jacht');t.scrollBy({left:d*((c?c.getBoundingClientRect().width:300)+16),behavior:'smooth'});}k.querySelector('.m9-kar-w').addEventListener('click',function(){s(-1)});k.querySelector('.m9-kar-d').addEventListener('click',function(){s(1)});function u(){k.classList.toggle('m9-kar-pocz',t.scrollLeft<8);k.classList.toggle('m9-kar-kon',t.scrollLeft+t.clientWidth>=t.scrollWidth-8);k.classList.toggle('m9-kar-bez',t.scrollWidth<=t.clientWidth+8);}t.addEventListener('scroll',u,{passive:true});addEventListener('resize',u);u();});</script>";
}, 62 );

/* f) poradniki: wpisy z bloga Marigo (tytul i adres z WordPressa; brakujacy wpis jest pomijany) */
function marigo_poradniki_lista( $sluga ) {
	$h = '';
	foreach ( $sluga as $s ) {
		$p = get_page_by_path( $s, OBJECT, array( 'post', 'page' ) );
		if ( ! $p || 'publish' !== $p->post_status ) { continue; }
		$h .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
	}
	return $h ? '<ul class="m9-por-lista">' . $h . '</ul>' : '';
}
add_shortcode( 'marigo_poradniki', function ( $atts ) {
	$a = shortcode_atts( array( 'typ' => 'motorowe' ), $atts );
	$grupy = array(
		'motorowe' => array( 'Jachty motorowe', array( 'jaki-jacht-motorowy-na-pierwszy-rejs', 'jak-manewrowac-jachtem-motorowym', 'jak-dziala-ster-strumieniowy', 'ranking-lodzi-motorowych-na-mazurach', 'skad-biora-sie-roznice-w-cenach-jachtow-motorowych-na-mazurach', 'gdzie-mozna-plywac-na-silniku-spalinowym-na-mazurach', 'nawodne-stacje-benzynowe-mazury', 'jak-wyglada-kurs-motorowodny' ) ),
		'zaglowe'  => array( 'Jachty żaglowe', array( 'zeglowanie-po-mazurach', 'szlak-zeglarski-gizycko-wegorzewo', 'szlak-zeglarski-gizycko-mikolajki', 'kladzenie-masztu', 'kierunki-i-rodzaje-wiatrow', 'prawo-drogi-na-srodladziu', 'jak-omijac-znaki-kardynalne', 'zeglowanie-po-mazurach-w-trudnych-warunkach' ) ),
	);
	$wspolne = array( 'Planowanie rejsu', array( 'ile-kosztuje-tygodniowy-rejs-po-mazurach', '7-dniowy-rejs-po-mazurach', 'rejs-3-dniowy-mazury', 'co-zabrac-na-rejs', 'cumowanie-jachtu-rufa', 'spanie-na-jachcie', 'kiedy-rezerwowac-lodke' ) );
	$g = isset( $grupy[ $a['typ'] ] ) ? $grupy[ $a['typ'] ] : $grupy['motorowe'];
	$h = '';
	foreach ( array( $g, $wspolne ) as $x ) {
		$l = marigo_poradniki_lista( $x[1] );
		if ( $l ) { $h .= '<div class="m9-por-kol"><p class="m9-etyk">' . esc_html( $x[0] ) . '</p>' . $l . '</div>'; }
	}
	return $h ? '<div class="m9-por">' . $h . '</div>' : '';
} );

/* g) porty startowe: kafelki ze strony glownej (grupa "m9-porty-siatka") */
add_shortcode( 'marigo_porty', function () {
	$id = (int) get_option( 'page_on_front' );
	if ( ! $id || ! class_exists( 'DOMDocument' ) ) { return ''; }
	$gl = get_post( $id );
	if ( ! $gl || false === strpos( $gl->post_content, 'm9-porty-siatka' ) ) { return ''; }
	$klucz = 'mg_porty_' . md5( $gl->post_modified_gmt . MARIGO_WERSJA );
	$c = get_transient( $klucz );
	if ( is_string( $c ) ) { return $c; }
	$dom = marigo_dom( do_blocks( $gl->post_content ) );
	$xp = new DOMXPath( $dom );
	$out = '';
	foreach ( $xp->query( '//*[contains(concat(" ", normalize-space(@class), " "), " m9-porty-siatka ")]' ) as $el ) {
		foreach ( $el->getElementsByTagName( 'img' ) as $im ) { $im->setAttribute( 'loading', 'lazy' ); $im->setAttribute( 'decoding', 'async' ); }
		$out = $dom->saveHTML( $el );
		break;
	}
	set_transient( $klucz, $out, WEEK_IN_SECONDS );
	return $out;
} );

/* h) strona glowna: filtr kart jachtow (same karty i naglowki "Jachty zaglowe / motorowe" bez zmian) */
add_action( 'wp_footer', function () {
	if ( ! marigo_tresc_zawiera( 'm9-flota' ) ) { return; }
	echo "<script>(function(){var s=document.querySelector('.m9-flota');if(!s)return;var karty=[].slice.call(s.querySelectorAll('article.mg-jacht'));if(karty.length<4)return;var F=[['wszystkie','Wszystkie'],['zaglowe','Żaglowe'],['motorowe','Motorowe'],['bez','Bez patentu']];var bar=document.createElement('div');bar.className='m9-filtr';bar.setAttribute('role','group');bar.setAttribute('aria-label','Pokaż jachty');var licz=document.createElement('span');licz.className='m9-filtr-n';function typ(a){var t=a.textContent.toLowerCase();return{zaglowe:t.indexOf('żaglow')>-1,motorowe:t.indexOf('motorow')>-1,bez:t.indexOf('bez patentu')>-1};}function ustaw(k){var n=0;karty.forEach(function(a){var w=k==='wszystkie'||typ(a)[k];a.hidden=!w;if(w)n++;});s.querySelectorAll('.mg-flota').forEach(function(f){var wid=[].some.call(f.querySelectorAll('article.mg-jacht'),function(a){return!a.hidden;});f.hidden=!wid;var h=f.previousElementSibling;if(h&&h.classList.contains('mg-flota-tyt'))h.hidden=!wid;});[].forEach.call(bar.querySelectorAll('button'),function(b){b.setAttribute('aria-pressed',b.getAttribute('data-k')===k?'true':'false');});licz.textContent=n+(n===1?' jacht':(n%10>=2&&n%10<=4&&(n%100<10||n%100>=20)?' jachty':' jachtów'));}F.forEach(function(f){var b=document.createElement('button');b.type='button';b.textContent=f[1];b.setAttribute('data-k',f[0]);b.addEventListener('click',function(){ustaw(f[0]);});bar.appendChild(b);});bar.appendChild(licz);var pierwszy=s.querySelector('.mg-flota-tyt')||s.querySelector('.mg-flota');pierwszy.parentNode.insertBefore(bar,pierwszy);ustaw('wszystkie');})();</script>";
}, 62 );
